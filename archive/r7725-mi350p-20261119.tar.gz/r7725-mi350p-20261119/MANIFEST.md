# R7725 / MI350P archive

Exported 2026-11-19T14:17:47+00:00 by
`scripts/archive_r7725.py` from `r7725mi350p`.

| Folder | Contents |
|---|---|
| `results/` | Every row of every `run.db`: runs with their full config (473), measured load steps (1085), telemetry samples (105547), from 473 databases |
| `run-files/` | Per-run JSON and the first 250 lines of each engine log, which hold the launch command (6242 files) |
| `runs-top/` | Queue and roofline definition files from `runs/` |
| `aiperf-benchmarks/` | AIPerf cross-check configs, manifests and reports (273 files; prompt sets left out) |
| `capsim/` | `/data/capsim` scripts, Dockerfiles, phase results, hardening, partition, profile and probe outputs (764 files) |
| `models.csv` | Every cached model with its exact revision and size (46 rows) |
| `system/` | CPU, memory, storage, GPU, ROCm, driver, kernel settings, container images with digests, build history |
| `code/` | Repo commit on the box, uncommitted changes as a patch, untracked files |

## Left out on purpose

Model weights (re-download by revision from `models.csv`), AIPerf prompt
sets and raw request exports, media probe frames and video, tool
environments, compiled files, full engine logs, and any file over
5 MB.

## Not captured

- BIOS settings, firmware versions and DIMM layout (need root: `dmidecode`,
  iDRAC export).
- The container images themselves (37 to 70 GB each). The Dockerfiles and
  base image digests are here; a rebuild depends on the upstream commits
  still being available.

## Files skipped for size

- `/data/capsim/logs/phase0_build_vllm.log (29 MB)`
- `/data/capsim/logs/phase0_build_sglang.log (5 MB)`
- `/home/user/system-sizing/runs/benchmarks/fc7ee79ef6dba766bbbeb4b9/attempts/0001-aiperf/engine_vllm_cuda_multi_022f5204.log (18 MB)`
- `/home/user/system-sizing/runs/benchmarks/6b771cf8e0f6af8f8bba62de/attempts/0001-aiperf/engine_sglang_cuda_364ce8a0.log (8 MB)`
