#!/usr/bin/env bash
# dig.sh : profile run with the sidecar, then the lever arms.
cd /data/capsim/dig
bash /data/capsim/phase0/prof_side.sh dig_qwen35 2000 > side.out 2>&1 &
bash /data/capsim/phase0/run_arms.sh /data/capsim/dig p
bash /data/capsim/phase0/run_arms.sh /data/capsim/dig e
