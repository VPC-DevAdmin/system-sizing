"""make_dig_arms.py : why the other models trail LFM2, and levers for them.
Bases are the spread-start single-engine runs (spx4 j2 Gemma 16,599,
j4 Qwen3.5 14,400). Each arm changes one thing."""
import json, os
os.makedirs("/data/capsim/dig/arms", exist_ok=True)
S = "/data/capsim/partition/spx4/arms/"
PROF = ["--profiler-config.profiler=torch",
        "--profiler-config.torch_profiler_dir=/root/.cache/huggingface/prof",
        "--profiler-config.torch_profiler_with_stack=false",
        "--profiler-config.torch_profiler_record_shapes=true"]
def arm(name, base, extra, hold=None):
    a = json.load(open(S + base + ".json"))
    a["custom"]["vllm_extra_flags"] = a["custom"]["vllm_extra_flags"] + extra
    if hold: a["hold_s"] = hold
    json.dump(a, open(f"/data/capsim/dig/arms/{name}.json", "w"), indent=1)
G, Q = "j2_gemma26_x1_spread23", "j4_qwen35a3b_x1_spread34"
arm("p1_qwen35_profile", Q, PROF, hold=150)
# Plain temperature sampling, as LFM2 bf16 runs (it ships no top-k/top-p defaults).
arm("e1_gemma_plain_sampling", G, ["--generation-config", "vllm"])
# Smaller cache blocks so the 71-token shared prompt can be reused.
arm("e2_gemma_block8", G, ["--block-size", "8"])
arm("e3_qwen35_plain_sampling", Q, ["--generation-config", "vllm"])
# No prefix cache: the recurrent state is then kept once per stream, not per block.
arm("e4_qwen35_no_prefix_cache", Q, ["--no-enable-prefix-caching"])
print(sorted(os.listdir("/data/capsim/dig/arms")))
