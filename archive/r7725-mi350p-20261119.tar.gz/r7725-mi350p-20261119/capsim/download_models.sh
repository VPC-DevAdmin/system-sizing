#!/usr/bin/env bash
export HF_HOME=/data/capsim/huggingface HF_HUB_ENABLE_HF_TRANSFER=0
HF=/home/user/.local/share/uv/tools/capsim/bin/hf
for m in openai/gpt-oss-20b Qwen/Qwen3.6-35B-A3B-FP8 mistralai/Mistral-Small-3.2-24B-Instruct-2506 openai/gpt-oss-120b zai-org/GLM-4.7-Flash RedHatAI/Llama-3.3-70B-Instruct-FP8-dynamic Qwen/Qwen3-Next-80B-A3B-Instruct-FP8; do
  echo "=== $(date +%T) $m"
  $HF download "$m" --quiet >/dev/null && echo "ok $m" || echo "FAILED $m"
done
echo "=== all done $(date +%T)"
