#!/usr/bin/env bash
# run.sh CMD... : run a command in the vLLM ROCm image with the GPU devices
# and /data/capsim/mediaprobe mounted at /work.
G=""; for g in $(stat -c %g /dev/kfd /dev/dri/renderD128 | sort -u); do G="$G --group-add $g"; done
exec docker run --rm --name mediaprobe-$$ --device=/dev/kfd --device=/dev/dri $G --ipc=host --network host \
  -v /data/capsim/mediaprobe:/work -w /work \
  -e D=/usr/local/lib/python3.12/dist-packages/_rocm_sdk_devel \
  --entrypoint sh capsim/vllm-rocm:nightly-9bc16ae6-aiter-95d21128 -c "$*"
