"""check_ppm.py PPM JPG : mean and max absolute difference between a frame the
card decoded (copied back once as a PPM) and a CPU decode of the same file."""
import sys, numpy as np
from PIL import Image
a = np.asarray(Image.open(sys.argv[1]).convert("RGB")).astype(int)
b = np.asarray(Image.open(sys.argv[2]).convert("RGB")).astype(int)
d = np.abs(a - b)
print(sys.argv[2], a.shape, "mean abs diff %.2f max %d" % (d.mean(), d.max()))
