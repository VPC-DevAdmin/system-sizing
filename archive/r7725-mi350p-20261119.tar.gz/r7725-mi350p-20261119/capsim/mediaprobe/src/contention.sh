#!/usr/bin/env bash
# contention.sh : JPEG decode alongside an inference load. capsim holds one
# vLLM engine (LFM2-24B-A2B, 4,096 streams) for 7 minutes; from about 2.5 to
# 4.5 minutes in, the card's JPEG engines are driven flat out (4 threads x
# batches of 16, 1080p). Inference rate before / during / after comes from
# capsim's per-second record; decode rate from the probe itself.
M=/data/capsim/mediaprobe; O=$M/out/contention; mkdir -p $O; rm -f $O/*
log() { echo "$(date '+%F %T') $(date +%s.%N) $*" >> $O/log.txt; }
curl -s -m 120 -X POST localhost:8321/api/runs -H 'Content-Type: application/json' -d @$M/src/contention_arm.json > $O/post.json
port() { docker inspect "$1" --format '{{join .Args " "}}' | grep -o '\-\-port [0-9]*' | cut -d' ' -f2; }
for i in $(seq 240); do c=$(docker ps --format '{{.Names}}' | grep '^vllm' | head -1); [ -n "$c" ] && curl -sf -m 3 localhost:$(port $c)/v1/models >/dev/null && break; sleep 5; done
log "engine ready $c"
python3 $M/src/sampler.py $O/smi.jsonl > /dev/null 2>&1 &
sleep 150
log "decode start"
$M/run.sh "end=\$((\$(date +%s) + 120)); while [ \$(date +%s) -lt \$end ]; do ./jpegprobe img/1080p rgb 4 16 2000 30 2>&1 | grep -E 'RESULT|FAIL|failed'; done" > $O/decode.log 2>&1
log "decode end"
until [ "$(curl -s -m 10 localhost:8321/api/status | grep -o '"running":[a-z]*' | cut -d: -f2)" != "true" ]; do sleep 10; done
touch $O/smi.jsonl.stop
log "run ended $(ls -td /home/user/system-sizing/runs/run_* | head -1)"
touch $O/done
