"""cpu_decode.py DIR [MAX] : CPU JPEG decode rate on the host cores with
libjpeg-turbo, through OpenCV and through Pillow. Files are read into memory
first. One process, then a pool of processes (each decoding to RGB arrays
that are thrown away), which is what a camera-ingest service would run."""
import glob, io, os, sys, time
from multiprocessing import Pool
import numpy as np, cv2
from PIL import Image
cv2.setNumThreads(1)
d = sys.argv[1]; mx = int(sys.argv[2]) if len(sys.argv) > 2 else 2000
STRIDE = int(sys.argv[3]) if len(sys.argv) > 3 else 1
BUFS = [open(p, "rb").read() for p in sorted(glob.glob(d + "/*.jpg"))[::STRIDE][:mx]]
ARRS = [np.frombuffer(b, np.uint8) for b in BUFS]
def cv_all(rep):
    n = 0
    for _ in range(rep):
        for a in ARRS:
            cv2.cvtColor(cv2.imdecode(a, cv2.IMREAD_COLOR), cv2.COLOR_BGR2RGB); n += 1
    return n
def pil_all(rep):
    n = 0
    for _ in range(rep):
        for b in BUFS:
            np.asarray(Image.open(io.BytesIO(b)).convert("RGB")); n += 1
    return n
def cv_bgr(rep):
    n = 0
    for _ in range(rep):
        for a in ARRS:
            cv2.imdecode(a, cv2.IMREAD_COLOR); n += 1
    return n
if __name__ == "__main__":
    print("dir", d, "images", len(BUFS), "cores", os.cpu_count())
    for name, fn in (("opencv_rgb", cv_all), ("opencv_bgr", cv_bgr), ("pillow_rgb", pil_all)):
        t = time.time(); n = fn(1); s = time.time() - t
        print(f"RESULT cpu {name} procs 1 images_per_s {n / s:.1f}")
    for procs in (24, 48, 96, 192):
        for name, fn in (("opencv_rgb", cv_all),):
            with Pool(procs) as p:
                p.map(cv_bgr, [0] * procs)           # start the workers
                rep = 2
                t = time.time(); n = sum(p.map(fn, [rep] * procs)); s = time.time() - t
            print(f"RESULT cpu {name} procs {procs} images_per_s {n / s:.1f} per_proc {n / s / procs:.1f}")
