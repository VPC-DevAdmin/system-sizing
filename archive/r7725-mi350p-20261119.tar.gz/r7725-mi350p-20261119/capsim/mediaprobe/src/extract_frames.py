"""extract_frames.py MOVIE OUT_DIR COUNT : real film frames as test JPEGs.

Decodes COUNT consecutive frames of MOVIE (1920x800, starting 20 s in) with
ffmpeg and writes each one three ways, baseline 4:2:0 JPEG at quality 90:

  real720   1280x720   centre crop, native pixels, no scaling
  real800   1920x800   the full frame, native pixels
  real1080  1920x1080  centre 1422x800 crop scaled up 1.35x (the film has
                       no 1080-line version at this download size)
"""
import os, subprocess, sys
from multiprocessing import Pool
from PIL import Image

movie, out, count = sys.argv[1], sys.argv[2], int(sys.argv[3])
W, H, FPS, START, CHUNK = 1920, 800, 24, 20.0, 500

def work(first):
    n = min(CHUNK, count - first)
    cmd = ["ffmpeg", "-v", "error", "-ss", f"{START + first / FPS:.4f}", "-i", movie, "-an", "-frames:v", str(n),
           "-f", "rawvideo", "-pix_fmt", "rgb24", "-"]
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE)
    sizes = [0, 0, 0]
    done = 0
    for i in range(n):
        raw = p.stdout.read(W * H * 3)
        if len(raw) < W * H * 3: break
        im = Image.frombytes("RGB", (W, H), raw)
        outs = (("real720", im.crop((320, 40, 1600, 760))),
                ("real800", im),
                ("real1080", im.crop((249, 0, 1671, 800)).resize((1920, 1080), Image.LANCZOS)))
        for k, (name, frame) in enumerate(outs):
            path = f"{out}/{name}/{first + i:05d}.jpg"
            frame.save(path, "JPEG", quality=90, subsampling="4:2:0", optimize=False, progressive=False)
            sizes[k] += os.path.getsize(path)
        done += 1
    p.stdout.close(); p.wait()
    return done, sizes

if __name__ == "__main__":
    for name in ("real720", "real800", "real1080"):
        os.makedirs(f"{out}/{name}", exist_ok=True)
    with Pool(32) as pool:
        res = pool.map(work, range(0, count, CHUNK))
    total = sum(r[0] for r in res)
    for k, name in enumerate(("real720", "real800", "real1080")):
        print(name, total, "files, mean bytes", sum(r[1][k] for r in res) // max(total, 1))
