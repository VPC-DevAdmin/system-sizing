// jpegprobe: rocJPEG decode-rate probe for the MI350P.
//
//   jpegprobe DIR FMT THREADS BATCH [MAX_IMAGES] [LOOPS] [DUMP.ppm]
//
// DIR      directory of .jpg files (all read into memory before timing)
// FMT      native | rgb   (native = NV12 planes as the hardware produces them;
//                          rgb = interleaved RGB, converted on the GPU)
// THREADS  decoder threads, each with its own rocJPEG handle and buffers
// BATCH    1 = rocJpegDecode per image; >1 = rocJpegDecodeBatched
//
// Output buffers are hipMalloc'd device memory and stay on the GPU; nothing
// is copied to the host inside the timed loop. With DUMP.ppm (rgb only) the
// first image is copied back once, after timing, to check the pixels.
#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <string>
#include <thread>
#include <vector>

#include "rocjpeg/rocjpeg.h"

struct Jpeg { std::vector<unsigned char> data; };

static const char* err(RocJpegStatus s) { return rocJpegGetErrorName(s); }

#define CHECK(call)                                                          \
    do {                                                                     \
        RocJpegStatus _s = (call);                                           \
        if (_s != ROCJPEG_STATUS_SUCCESS) {                                  \
            fprintf(stderr, "FAIL %s -> %d (%s)\n", #call, (int)_s, err(_s)); \
            return false;                                                    \
        }                                                                    \
    } while (0)

struct Worker {
    RocJpegHandle handle = nullptr;
    std::vector<RocJpegStreamHandle> streams;
    std::vector<RocJpegImage> images;
    size_t bytes[2] = {0, 0};
    uint32_t first_w = 0, first_h = 0;
    RocJpegChromaSubsampling first_css = ROCJPEG_CSS_UNKNOWN;

    bool init(int device, int batch, bool rgb, uint32_t max_w, uint32_t max_h) {
        CHECK(rocJpegCreate(ROCJPEG_BACKEND_HARDWARE, device, &handle));
        streams.resize(batch);
        images.resize(batch);
        // Generous sizes: height rounded up to 16 plus a row of slack.
        uint32_t h = ((max_h + 15) / 16) * 16 + 16;
        bytes[0] = rgb ? (size_t)max_w * 3 * h : (size_t)max_w * h;
        bytes[1] = rgb ? 0 : (size_t)max_w * (h / 2);
        for (int i = 0; i < batch; i++) {
            CHECK(rocJpegStreamCreate(&streams[i]));
            memset(&images[i], 0, sizeof(RocJpegImage));
            for (int c = 0; c < 2; c++) {
                if (!bytes[c]) continue;
                void* p = nullptr;
                if (hipMalloc(&p, bytes[c]) != hipSuccess) { fprintf(stderr, "hipMalloc failed\n"); return false; }
                images[i].channel[c] = (uint8_t*)p;
            }
        }
        return true;
    }

    // Decode jpegs[idx[k]] for k in [0, n); n <= batch.
    bool decode(const std::vector<Jpeg>& jpegs, const size_t* idx, int n, bool rgb) {
        // rocJpegDecodeBatched reads one RocJpegDecodeParams per image.
        std::vector<RocJpegDecodeParams> params(n);
        memset(params.data(), 0, sizeof(RocJpegDecodeParams) * n);
        for (auto& p : params) p.output_format = rgb ? ROCJPEG_OUTPUT_RGB : ROCJPEG_OUTPUT_NATIVE;
        for (int k = 0; k < n; k++) {
            const Jpeg& j = jpegs[idx[k]];
            CHECK(rocJpegStreamParse(j.data.data(), j.data.size(), streams[k]));
            uint8_t comps = 0;
            RocJpegChromaSubsampling css;
            uint32_t w[ROCJPEG_MAX_COMPONENT] = {0}, h[ROCJPEG_MAX_COMPONENT] = {0};
            CHECK(rocJpegGetImageInfo(handle, streams[k], &comps, &css, w, h));
            if (!first_w) { first_w = w[0]; first_h = h[0]; first_css = css; }
            if (rgb) {
                images[k].pitch[0] = w[0] * 3;
            } else {
                images[k].pitch[0] = w[0];
                images[k].pitch[1] = w[0];
            }
        }
        if (n == 1) {
            CHECK(rocJpegDecode(handle, streams[0], params.data(), &images[0]));
        } else {
            CHECK(rocJpegDecodeBatched(handle, streams.data(), n, params.data(), images.data()));
        }
        return true;
    }
};

int main(int argc, char** argv) {
    if (argc < 5) {
        fprintf(stderr, "usage: %s DIR native|rgb THREADS BATCH [MAX_IMAGES] [LOOPS] [DUMP.ppm]\n", argv[0]);
        return 2;
    }
    std::string dir = argv[1];
    bool rgb = std::string(argv[2]) == "rgb";
    int threads = atoi(argv[3]);
    int batch = atoi(argv[4]);
    size_t max_images = argc > 5 ? strtoul(argv[5], nullptr, 10) : 0;
    int loops = argc > 6 ? atoi(argv[6]) : 1;
    const char* dump = argc > 7 ? argv[7] : nullptr;

    std::vector<std::string> names;
    for (auto& e : std::filesystem::directory_iterator(dir)) {
        auto ext = e.path().extension().string();
        if (ext == ".jpg" || ext == ".jpeg" || ext == ".JPG") names.push_back(e.path().string());
    }
    std::sort(names.begin(), names.end());
    if (max_images && names.size() > max_images) names.resize(max_images);
    std::vector<Jpeg> jpegs(names.size());
    size_t total_bytes = 0;
    for (size_t i = 0; i < names.size(); i++) {
        std::ifstream f(names[i], std::ios::binary);
        jpegs[i].data.assign(std::istreambuf_iterator<char>(f), {});
        total_bytes += jpegs[i].data.size();
    }
    if (jpegs.empty()) { fprintf(stderr, "no jpegs in %s\n", dir.c_str()); return 2; }
    printf("images %zu  mean_bytes %zu  fmt %s  threads %d  batch %d  loops %d\n",
           jpegs.size(), total_bytes / jpegs.size(), rgb ? "rgb" : "native", threads, batch, loops);

    if (hipInit(0) != hipSuccess) { fprintf(stderr, "hipInit failed\n"); return 1; }
    int ndev = 0;
    hipGetDeviceCount(&ndev);
    hipDeviceProp_t prop;
    hipGetDeviceProperties(&prop, 0);
    printf("hip devices %d  device0 %s (%s)\n", ndev, prop.name, prop.gcnArchName);

    std::vector<Worker> workers(threads);
    for (int t = 0; t < threads; t++) {
        if (!workers[t].init(0, batch, rgb, 1920, 1088)) { fprintf(stderr, "worker %d init failed\n", t); return 1; }
    }
    printf("init ok: %d rocJPEG handle(s) created on device 0 (hardware backend)\n", threads);

    // One untimed image per worker, so first-use setup is outside the clock.
    for (int t = 0; t < threads; t++) {
        size_t z = 0;
        if (!workers[t].decode(jpegs, &z, 1, rgb)) { fprintf(stderr, "first decode failed\n"); return 1; }
    }
    hipDeviceSynchronize();
    printf("first decode ok: %ux%u subsampling %d\n", workers[0].first_w, workers[0].first_h, (int)workers[0].first_css);

    std::atomic<size_t> next{0};
    std::atomic<bool> failed{false};
    size_t total = jpegs.size() * (size_t)loops;
    auto t0 = std::chrono::steady_clock::now();
    std::vector<std::thread> pool;
    for (int t = 0; t < threads; t++) {
        pool.emplace_back([&, t] {
            std::vector<size_t> idx(batch);
            while (!failed) {
                size_t start = next.fetch_add(batch);
                if (start >= total) break;
                int n = (int)std::min<size_t>(batch, total - start);
                for (int k = 0; k < n; k++) idx[k] = (start + k) % jpegs.size();
                if (!workers[t].decode(jpegs, idx.data(), n, rgb)) failed = true;
            }
        });
    }
    for (auto& th : pool) th.join();
    hipDeviceSynchronize();
    double s = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
    if (failed) { fprintf(stderr, "decode failed during the timed loop\n"); return 1; }
    printf("RESULT images %zu seconds %.3f images_per_s %.1f megapixels_per_s %.1f\n", total, s, total / s,
           total / s * workers[0].first_w * workers[0].first_h / 1e6);

    if (dump && rgb) {
        // Decode a full batch again and copy back its LAST slot, so the
        // batched path's output is what gets checked.
        std::vector<size_t> idx(batch);
        for (int k = 0; k < batch; k++) idx[k] = k % jpegs.size();
        workers[0].decode(jpegs, idx.data(), batch, true);
        hipDeviceSynchronize();
        uint32_t w = workers[0].first_w, h = workers[0].first_h;
        std::vector<unsigned char> host((size_t)w * 3 * h);
        hipMemcpy(host.data(), workers[0].images[batch - 1].channel[0], host.size(), hipMemcpyDeviceToHost);
        FILE* f = fopen(dump, "wb");
        fprintf(f, "P6\n%u %u\n255\n", w, h);
        fwrite(host.data(), 1, host.size(), f);
        fclose(f);
        printf("dumped image index %d (last slot of a batch of %d) to %s\n", (batch - 1) % (int)jpegs.size(), batch, dump);
    }
    return 0;
}
