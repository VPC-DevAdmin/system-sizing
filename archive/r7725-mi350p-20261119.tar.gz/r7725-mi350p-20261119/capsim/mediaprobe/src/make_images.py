"""make_images.py SRC_DIR OUT_DIR COUNT : provisional test JPEGs.

Random crops of the few photographs on the box, scaled to 1280x720 and
1920x1080 and saved as baseline 4:2:0 JPEG at quality 90 (what a camera's
Motion-JPEG stream carries). The sources are about 1,000 pixels wide, so
these are upscaled and carry less fine detail than native camera frames:
good enough to see whether the engines work and scale, not for a rate to
quote.
"""
import glob, os, random, sys
from PIL import Image

src, out, count = sys.argv[1], sys.argv[2], int(sys.argv[3])
random.seed(7)
photos = [Image.open(p).convert("RGB") for p in sorted(glob.glob(src + "/*.jpg"))]
print("sources", [(p.size) for p in photos])
for name, (w, h) in (("720p", (1280, 720)), ("1080p", (1920, 1080))):
    d = f"{out}/{name}"
    os.makedirs(d, exist_ok=True)
    total = 0
    for i in range(count):
        im = random.choice(photos)
        sw, sh = im.size
        # A 16:9 window covering 60-100% of the source width, anywhere in it.
        cw = int(sw * random.uniform(0.6, 1.0)); ch = int(cw * 9 / 16)
        if ch > sh: ch = sh; cw = int(ch * 16 / 9)
        x = random.randint(0, sw - cw); y = random.randint(0, sh - ch)
        crop = im.crop((x, y, x + cw, y + ch)).resize((w, h), Image.LANCZOS)
        if random.random() < 0.5: crop = crop.transpose(Image.FLIP_LEFT_RIGHT)
        p = f"{d}/{i:05d}.jpg"
        crop.save(p, "JPEG", quality=90, subsampling="4:2:0", optimize=False, progressive=False)
        total += os.path.getsize(p)
    print(name, count, "files, mean bytes", total // count)
