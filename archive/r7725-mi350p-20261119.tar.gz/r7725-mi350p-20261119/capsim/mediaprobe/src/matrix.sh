#!/bin/sh
# Inside the container: the rocJPEG decode matrix. Each line of matrix.log
# has the wall-clock start and end so the amd-smi samples can be lined up.
run() { # size fmt threads batch loops
  s=$(date +%s.%N)
  r=$(./jpegprobe img/$1 $2 $3 $4 2000 $5 2>&1 | grep -E "RESULT|FAIL|failed" | tail -1)
  echo "$1 $2 threads=$3 batch=$4 start=$s end=$(date +%s.%N) $r"
}
for size in 720p 1080p; do
  for fmt in native rgb; do
    run $size $fmt 1 1 4
  done
  for b in 4 16 32 64; do run $size rgb 1 $b 6; done
  for t in 2 4 8 16 20 32 64; do run $size rgb $t 1 20; done
  for t in 8 20; do run $size native $t 1 20; done
  for t in 4 8 20; do run $size rgb $t 16 20; done
done
