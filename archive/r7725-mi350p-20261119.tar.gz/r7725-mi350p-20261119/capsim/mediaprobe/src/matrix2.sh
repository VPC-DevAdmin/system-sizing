#!/bin/sh
# Batched rows again after the per-image decode-params fix.
run() { s=$(date +%s.%N); r=$(./jpegprobe img/$1 $2 $3 $4 2000 $5 2>&1 | grep -E "RESULT|FAIL|failed" | tail -1); echo "$1 $2 threads=$3 batch=$4 start=$s end=$(date +%s.%N) $r"; }
for size in 720p 1080p; do
  for b in 4 16 32 64; do run $size rgb 1 $b 20; done
  for t in 2 4 8 20; do run $size rgb $t 16 40; done
  run $size native 4 16 40
  run $size rgb 32 1 40
done
