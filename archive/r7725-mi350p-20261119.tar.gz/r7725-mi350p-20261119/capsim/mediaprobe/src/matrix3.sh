#!/bin/sh
# Inside the container: the rocJPEG matrix on the real film frames
# (10,000 per set). Wall-clock start and end on each line for the sampler.
run() { s=$(date +%s.%N); r=$(./jpegprobe img/$1 $2 $3 $4 10000 $5 2>&1 | grep -E "RESULT|FAIL|failed" | tail -1); echo "$1 $2 threads=$3 batch=$4 start=$s end=$(date +%s.%N) $r"; }
for size in real720 real800 real1080; do
  run $size rgb 1 1 1
  run $size rgb 1 16 4
  run $size rgb 20 1 8
  for t in 4 8 20; do run $size rgb $t 16 12; done
  run $size native 4 16 12
done
