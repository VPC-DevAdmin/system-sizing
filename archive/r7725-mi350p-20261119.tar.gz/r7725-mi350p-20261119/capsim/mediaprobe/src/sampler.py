#!/usr/bin/env python3
"""sampler.py OUT : once a second, the card's JPEG and VCN engine busy
figures, GFX activity and socket power from amd-smi. Stops when OUT.stop
exists."""
import json, os, subprocess, sys, time
out = sys.argv[1]
def vals(v):
    if isinstance(v, dict):
        v = [x for part in v.values() for x in part]
    return [x.get("value") if isinstance(x, dict) else None for x in (v or [])]
with open(out, "w") as f:
    while not os.path.exists(out + ".stop"):
        t = time.time()
        try:
            d = json.loads(subprocess.run(["amd-smi", "metric", "-g", "0", "--usage", "--power", "--json"],
                                          capture_output=True, text=True, timeout=10).stdout)["gpu_data"][0]
            u = d["usage"]
            f.write(json.dumps({"t": round(t, 2), "gfx": (u.get("gfx_activity") or {}).get("value"),
                                "jpeg": vals(u.get("jpeg_busy")), "vcn": vals(u.get("vcn_busy")),
                                "power": (d.get("power", {}).get("socket_power") or {}).get("value")}) + "\n")
            f.flush()
        except Exception as e:
            f.write(json.dumps({"t": round(t, 2), "error": str(e)[:100]}) + "\n")
        time.sleep(max(0.0, 1.0 - (time.time() - t)))
