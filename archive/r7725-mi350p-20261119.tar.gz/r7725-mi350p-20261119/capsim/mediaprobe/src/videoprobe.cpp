// videoprobe: rocDecode probe for the MI350P.
//
//   videoprobe FILE STREAMS [LOOPS]
//
// FILE is an H.264 or HEVC elementary stream (Annex B). STREAMS decoders run
// at once, each in its own thread with its own reader, parser and decoder,
// each decoding FILE LOOPS times. Frames are fetched as GPU surfaces
// (rocDecGetVideoFrame) and counted; nothing is copied to the host.
#include <atomic>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <thread>
#include <vector>

#include "rocdecode/roc_bitstream_reader.h"
#include "rocdecode/rocdecode.h"
#include "rocdecode/rocparser.h"

struct Stream {
    int id = 0;
    rocDecDecoderHandle decoder = nullptr;
    RocdecVideoParser parser = nullptr;
    long frames = 0;
    bool failed = false;
    bool announced = false;
    uint32_t width = 0, height = 0;

    static int ROCDECAPI OnSequence(void* u, RocdecVideoFormat* f) { return ((Stream*)u)->Sequence(f); }
    static int ROCDECAPI OnDecode(void* u, RocdecPicParams* p) { return ((Stream*)u)->Decode(p); }
    static int ROCDECAPI OnDisplay(void* u, RocdecParserDispInfo* d) { return ((Stream*)u)->Display(d); }

    int Sequence(RocdecVideoFormat* f) {
        if (decoder) return f->min_num_decode_surfaces;   // same format on a later loop
        RocdecDecodeCaps caps;
        memset(&caps, 0, sizeof(caps));
        caps.device_id = 0;
        caps.codec_type = f->codec;
        caps.chroma_format = f->chroma_format;
        caps.bit_depth_minus_8 = f->bit_depth_luma_minus8;
        rocDecStatus s = rocDecGetDecoderCaps(&caps);
        if (id == 0 && !announced) {
            printf("caps: status %d (%s) supported %d num_decoders %d max %ux%u output_format_mask 0x%x\n", (int)s,
                   rocDecGetErrorName(s), caps.is_supported, caps.num_decoders, caps.max_width, caps.max_height,
                   caps.output_format_mask);
            printf("stream: codec %d %ux%u chroma %d bit depth %d min surfaces %d\n", (int)f->codec, f->coded_width,
                   f->coded_height, (int)f->chroma_format, 8 + f->bit_depth_luma_minus8, f->min_num_decode_surfaces);
            announced = true;
        }
        if (s != ROCDEC_SUCCESS || !caps.is_supported) { failed = true; return 0; }
        RocDecoderCreateInfo ci;
        memset(&ci, 0, sizeof(ci));
        ci.device_id = 0;
        ci.codec_type = f->codec;
        ci.chroma_format = f->chroma_format;
        ci.bit_depth_minus_8 = f->bit_depth_luma_minus8;
        ci.width = f->coded_width;
        ci.height = f->coded_height;
        ci.max_width = f->coded_width;
        ci.max_height = f->coded_height;
        ci.num_decode_surfaces = f->min_num_decode_surfaces;
        ci.output_format = rocDecVideoSurfaceFormat_NV12;
        ci.display_rect.left = f->display_area.left;
        ci.display_rect.top = f->display_area.top;
        ci.display_rect.right = f->display_area.right;
        ci.display_rect.bottom = f->display_area.bottom;
        width = (f->display_area.right - f->display_area.left + 1) & ~1;
        height = (f->display_area.bottom - f->display_area.top + 1) & ~1;
        ci.target_width = width;
        ci.target_height = height;
        ci.num_output_surfaces = 1;
        s = rocDecCreateDecoder(&decoder, &ci);
        if (s != ROCDEC_SUCCESS) {
            fprintf(stderr, "stream %d: rocDecCreateDecoder -> %d (%s)\n", id, (int)s, rocDecGetErrorName(s));
            failed = true;
            return 0;
        }
        return f->min_num_decode_surfaces;
    }

    int Decode(RocdecPicParams* p) {
        rocDecStatus s = rocDecDecodeFrame(decoder, p);
        if (s != ROCDEC_SUCCESS) {
            if (!failed) fprintf(stderr, "stream %d: rocDecDecodeFrame -> %d (%s)\n", id, (int)s, rocDecGetErrorName(s));
            failed = true;
            return 0;
        }
        return 1;
    }

    int Display(RocdecParserDispInfo* d) {
        if (!d) return 1;   // end-of-stream marker
        void* planes[3] = {nullptr, nullptr, nullptr};
        uint32_t pitch = 0;
        RocdecProcParams pp;
        memset(&pp, 0, sizeof(pp));
        pp.progressive_frame = d->progressive_frame;
        pp.top_field_first = d->top_field_first;
        rocDecStatus s = rocDecGetVideoFrame(decoder, d->picture_index, planes, &pitch, &pp);
        if (s != ROCDEC_SUCCESS) {
            if (!failed) fprintf(stderr, "stream %d: rocDecGetVideoFrame -> %d (%s)\n", id, (int)s, rocDecGetErrorName(s));
            failed = true;
            return 0;
        }
        if (id == 0 && frames == 0) printf("first frame: GPU plane pointers %p %p pitch %u\n", planes[0], planes[1], pitch);
        frames++;
        return 1;
    }

    void Run(const char* path, int loops) {
        for (int l = 0; l < loops && !failed; l++) {
            RocdecBitstreamReader reader = nullptr;
            if (rocDecCreateBitstreamReader(&reader, path) != ROCDEC_SUCCESS) { fprintf(stderr, "cannot read %s\n", path); failed = true; return; }
            rocDecVideoCodec codec;
            if (rocDecGetBitstreamCodecType(reader, &codec) != ROCDEC_SUCCESS) { fprintf(stderr, "codec not recognised\n"); failed = true; return; }
            if (!parser) {
                RocdecParserParams pp;
                memset(&pp, 0, sizeof(pp));
                pp.codec_type = codec;
                pp.max_num_decode_surfaces = 1;
                pp.max_display_delay = 1;
                pp.user_data = this;
                pp.pfn_sequence_callback = OnSequence;
                pp.pfn_decode_picture = OnDecode;
                pp.pfn_display_picture = OnDisplay;
                rocDecStatus s = rocDecCreateVideoParser(&parser, &pp);
                if (s != ROCDEC_SUCCESS) { fprintf(stderr, "rocDecCreateVideoParser -> %d (%s)\n", (int)s, rocDecGetErrorName(s)); failed = true; return; }
            }
            while (!failed) {
                uint8_t* data = nullptr;
                int size = 0;
                int64_t pts = 0;
                if (rocDecGetBitstreamPicData(reader, &data, &size, &pts) != ROCDEC_SUCCESS) { failed = true; break; }
                RocdecSourceDataPacket pkt;
                memset(&pkt, 0, sizeof(pkt));
                pkt.payload = data;
                pkt.payload_size = size;
                pkt.pts = pts;
                pkt.flags = ROCDEC_PKT_TIMESTAMP;
                if (size <= 0) pkt.flags |= ROCDEC_PKT_ENDOFSTREAM;
                rocDecStatus s = rocDecParseVideoData(parser, &pkt);
                if (s != ROCDEC_SUCCESS) { fprintf(stderr, "stream %d: rocDecParseVideoData -> %d (%s)\n", id, (int)s, rocDecGetErrorName(s)); failed = true; }
                if (size <= 0) break;
            }
            rocDecDestroyBitstreamReader(reader);
        }
    }
};

int main(int argc, char** argv) {
    if (argc < 3) { fprintf(stderr, "usage: %s FILE STREAMS [LOOPS]\n", argv[0]); return 2; }
    const char* path = argv[1];
    int n = atoi(argv[2]);
    int loops = argc > 3 ? atoi(argv[3]) : 1;
    std::vector<Stream> streams(n);
    for (int i = 0; i < n; i++) streams[i].id = i;
    auto t0 = std::chrono::steady_clock::now();
    std::vector<std::thread> pool;
    for (int i = 0; i < n; i++) pool.emplace_back([&, i] { streams[i].Run(path, loops); });
    for (auto& t : pool) t.join();
    double s = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
    long total = 0;
    int bad = 0;
    for (auto& st : streams) { total += st.frames; bad += st.failed; }
    printf("RESULT file %s streams %d failed %d frames %ld seconds %.2f fps_total %.1f fps_per_stream %.1f size %ux%u\n", path, n, bad,
           total, s, total / s, total / s / n, streams[0].width, streams[0].height);
    return bad ? 1 : 0;
}
