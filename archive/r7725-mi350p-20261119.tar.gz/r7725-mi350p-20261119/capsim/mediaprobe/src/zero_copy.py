"""zero_copy.py DIR : does rocJPEG output land in memory PyTorch can use
without a trip through the host?

Allocates a uint8 tensor on the GPU with PyTorch, hands rocJPEG that
tensor's device pointer as the output buffer, decodes into it, and compares
the tensor with a CPU decode of the same file. If the tensor holds the
picture, the decoded image went from the JPEG engine to PyTorch memory with
no host copy. Then times a batch decoded straight into one (N, H, W, 3)
tensor and a float conversion on it.
"""
import ctypes, glob, sys, time
import numpy as np, torch
from PIL import Image

# The image carries two copies of the ROCm libraries. rocJPEG must be the one
# that shares PyTorch's HIP runtime (LIB env overrides), or the tensor's
# device pointer means nothing to it.
import os
torch.zeros(1, device="cuda")
LIBPATH = os.environ.get("ROCJPEG_LIB", "/usr/local/lib/python3.12/dist-packages/_rocm_sdk_core/lib/librocjpeg.so.1")
lib = ctypes.CDLL(LIBPATH)
maps = sorted({l.split()[-1] for l in open("/proc/self/maps") if "libamdhip64" in l or "librocjpeg" in l})
print("loaded:", maps)

class Image4(ctypes.Structure):
    _fields_ = [("channel", ctypes.c_void_p * 4), ("pitch", ctypes.c_uint32 * 4)]

class Crop(ctypes.Structure):
    _fields_ = [("left", ctypes.c_int16), ("top", ctypes.c_int16), ("right", ctypes.c_int16), ("bottom", ctypes.c_int16)]

class Target(ctypes.Structure):
    _fields_ = [("width", ctypes.c_uint32), ("height", ctypes.c_uint32)]

class Params(ctypes.Structure):
    _fields_ = [("output_format", ctypes.c_int), ("crop", Crop), ("target", Target)]

RGB = 3
lib.rocJpegGetErrorName.restype = ctypes.c_char_p
def ok(status, what):
    if status != 0:
        raise SystemExit(f"FAIL {what}: {status} {lib.rocJpegGetErrorName(status).decode()}")

files = sorted(glob.glob(sys.argv[1] + "/*.jpg"))[:256]
bufs = [open(p, "rb").read() for p in files]
torch.zeros(1, device="cuda")                      # PyTorch owns the device context first
print("torch", torch.__version__, torch.cuda.get_device_name(0))

handle = ctypes.c_void_p()
ok(lib.rocJpegCreate(0, 0, ctypes.byref(handle)), "rocJpegCreate")
N = int(os.environ.get("ZC_BATCH", "64"))
SEPARATE = os.environ.get("ZC_SEPARATE") == "1"      # one tensor per image, not one batch tensor
streams = (ctypes.c_void_p * N)()
for i in range(N):
    s = ctypes.c_void_p(); ok(lib.rocJpegStreamCreate(ctypes.byref(s)), "stream create"); streams[i] = s.value

def info(stream):
    comps = ctypes.c_uint8(); css = ctypes.c_int()
    w = (ctypes.c_uint32 * 4)(); h = (ctypes.c_uint32 * 4)()
    ok(lib.rocJpegGetImageInfo(handle, ctypes.c_void_p(stream), ctypes.byref(comps), ctypes.byref(css), w, h), "image info")
    return w[0], h[0]

# 1. One image into a PyTorch tensor, checked against a CPU decode.
ok(lib.rocJpegStreamParse(bufs[0], len(bufs[0]), ctypes.c_void_p(streams[0])), "parse")
W, H = info(streams[0])
t = torch.zeros((H + 32, W, 3), dtype=torch.uint8, device="cuda")   # slack rows below the picture
img = Image4(); img.channel[0] = t.data_ptr(); img.pitch[0] = W * 3
p = Params(); p.output_format = RGB
ok(lib.rocJpegDecode(handle, ctypes.c_void_p(streams[0]), ctypes.byref(p), ctypes.byref(img)), "decode")
torch.cuda.synchronize()
ref = torch.from_numpy(np.asarray(Image.open(files[0]).convert("RGB")).copy()).cuda()
diff = (t[:H].int() - ref.int()).abs().float()
print(f"decoded {W}x{H} into a torch cuda tensor: mean abs diff vs CPU decode {diff.mean().item():.2f}, max {int(diff.max().item())}, "
      f"slack rows untouched: {bool((t[H:] == 0).all().item())}")

# 2. Batches of N straight into one (N, H+32, W, 3) tensor, then a float op on the GPU.
batch = torch.zeros((N, H + 32, W, 3), dtype=torch.uint8, device="cuda")
parts = [torch.zeros((H + 32, W, 3), dtype=torch.uint8, device="cuda") for _ in range(N)] if SEPARATE else None
imgs = (Image4 * N)()
for i in range(N):
    imgs[i].channel[0] = (parts[i] if SEPARATE else batch[i]).data_ptr(); imgs[i].pitch[0] = W * 3
print("batch", N, "separate tensors" if SEPARATE else "one batch tensor", flush=True)
pN = (Params * N)()                      # the batched call reads one Params per image
for i in range(N):
    pN[i].output_format = RGB
def decode_batch(start):
    for i in range(N):
        b = bufs[(start + i) % len(bufs)]
        ok(lib.rocJpegStreamParse(b, len(b), ctypes.c_void_p(streams[i])), "parse")
        info(streams[i])
    ok(lib.rocJpegDecodeBatched(handle, streams, N, pN, imgs), "batched decode")
decode_batch(0); torch.cuda.synchronize()
rounds = 40
t0 = time.time()
for r in range(rounds):
    decode_batch(r * N)
    src = torch.stack(parts) if SEPARATE else batch
    x = src[:, :H].permute(0, 3, 1, 2).float().div_(255)         # NCHW float, still on the GPU
    m = x.mean()
torch.cuda.synchronize()
s = time.time() - t0
print(f"RESULT zero_copy batch {N} images_per_s {rounds * N / s:.1f} (decode into torch tensor + float conversion on GPU), last mean {m.item():.4f}")
