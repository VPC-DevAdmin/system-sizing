#!/usr/bin/env bash
# Start the cpx2 arms once the cpx queue has ended and nothing is running.
until grep -q "all arms done" /data/capsim/partition/cpx/queue.log; do sleep 20; done
sleep 30
exec bash /data/capsim/phase0/run_arms.sh /data/capsim/partition/cpx2
