#!/usr/bin/env bash
# inspect.sh : record what the card looks like in its current partition
# mode. Read-only, no root. Writes /data/capsim/partition/inspect_<MODE>.txt.
P=/sys/bus/pci/devices/0000:8b:00.0
MODE=$(cat $P/current_compute_partition)
OUT=/data/capsim/partition/inspect_$MODE.txt
{
  echo "== $(date -u +%FT%TZ) mode $MODE memory $(cat $P/current_memory_partition) alloc $(cat $P/compute_partition_mem_alloc_mode)"
  echo "== amd-smi partition --current"; amd-smi partition --current 2>&1
  echo "== amd-smi list"; amd-smi list 2>&1
  echo "== amd-smi static --asic --vram --json"; amd-smi static --asic --vram --json 2>&1
  echo "== amd-smi metric --mem-usage --power --usage"; amd-smi metric --mem-usage --power --usage 2>&1
  echo "== render nodes"; ls -la /dev/dri/by-path 2>&1
  echo "== PyTorch in the vLLM image"
  G=""; for g in $(stat -c %g /dev/kfd /dev/dri/renderD128 | sort -u); do G="$G --group-add $g"; done
  docker run --rm --device=/dev/kfd --device=/dev/dri $G --entrypoint python3 \
    capsim/vllm-rocm:nightly-9bc16ae6-aiter-95d21128 -c '
import torch
n = torch.cuda.device_count()
print("devices", n)
for i in range(n):
    free, total = torch.cuda.mem_get_info(i)
    p = torch.cuda.get_device_properties(i)
    print(i, p.name, "total GiB %.1f free GiB %.1f" % (total / 2**30, free / 2**30))
' 2>&1 | grep -v "os_same_file\|bad things"
} > "$OUT" 2>&1
echo "wrote $OUT"; tail -8 "$OUT"
