"""make_cpx_arms.py OUT_DIR : four-way partition (CPX) arms. One engine
per partition (capsim sees four 36 GB GPUs), each with a quarter of the
whole-card stream count; 10-minute hold at 128 in / 256 out, the same
serving settings as the whole-card references."""
import json, os, sys
out = sys.argv[1]
os.makedirs(out, exist_ok=True)
IMAGE = "capsim/vllm-rocm:nightly-9bc16ae6-aiter-95d21128"
ENV = {"VLLM_ROCM_USE_AITER": "1", "HSA_NO_SCRATCH_RECLAIM": "1"}
SERVE = ["--stream-interval", "8", "--api-server-count", "4"]
STATE = ["--mamba-ssm-cache-dtype", "bfloat16", "--attention-backend", "ROCM_AITER_FA"]
MODELS = [  # name, model id, total streams, flags, trust_remote_code
    ("lfm25fp8", "LiquidAI/LFM2.5-24B-A2B-FP8", 8192, SERVE, True),
    ("qwen35a3b", "amd/Qwen3.5-35B-A3B-MXFP4", 2048, STATE + SERVE, False),
    ("qwen38", "amd/Qwen3.8-27B-Quark-AWQ-MXFP4", 1024, STATE, False),
    ("gemma26", "RedHatAI/gemma-4-26B-A4B-it-FP8-dynamic", 1536, SERVE, False),
]
for i, (name, model, streams, flags, trust) in enumerate(MODELS, 1):
    c = {"engine": "vllm_cuda_multi", "model_id": model, "tp": 1, "replicas": 4, "max_model_len": 2048,
         "gpu_memory_utilization": 0.95, "kv_cache_dtype": "fp8", "max_num_seqs": streams // 4,
         "vllm_gpu_image": IMAGE, "vllm_extra_env": ENV, "vllm_extra_flags": flags}
    if trust: c["trust_remote_code"] = True
    arm = {"workload": {"kind": "persona", "id": "headline_generation"}, "shape": {"input_tokens": 128, "output_tokens": 256},
           "ladder": [streams], "hold_s": 600, "new_run": True, "prefix_reuse": "industry", "custom": c}
    json.dump(arm, open(f"{out}/c{i}_{name}_cpx4.json", "w"), indent=1)
print(sorted(os.listdir(out)))
