"""make_dpx2_arms.py : second two-way queue for LFM2 bf16, one engine per half."""
import json, os
os.makedirs("dpx2/arms", exist_ok=True)
a = json.load(open("dpx/arms/f1_dpx_2x1_lfm2_bf16.json"))
a["spread_s"] = 50
# i1: the best layout so far with stream starts spread over 50 s.
json.dump(a, open("dpx2/arms/i1_dpx_2x1_lfm2_bf16_spread50.json", "w"), indent=1)
# i2: i1 with the session cache left in the model's own precision instead of FP8.
b = json.loads(json.dumps(a)); b["custom"].pop("kv_cache_dtype", None)
json.dump(b, open("dpx2/arms/i2_dpx_2x1_lfm2_bf16_spread50_kvauto.json", "w"), indent=1)
# i3: i1 again, for a range on the recommended setting.
json.dump(a, open("dpx2/arms/i3_dpx_2x1_lfm2_bf16_spread50_repeat.json", "w"), indent=1)
print(sorted(os.listdir("dpx2/arms")))
