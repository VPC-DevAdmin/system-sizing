"""make_dpx_arms.py OUT_DIR : two-way partition (DPX) arms for LFM2.
capsim sees two 72 GB GPUs. 10-minute holds at 128 in / 256 out.

f1  one engine per half, LFM2 bf16, 4,096 streams each: the same engines,
    memory and streams as the 42,081 whole-card run, so the difference is
    the partition boundary alone.
f2  f1 with a 32,768-token step budget (default 8,192): a finished wave of
    streams is re-admitted in a few steps instead of about fifty.
f3  two engines per half, LFM2.5 FP8, 1,280 streams each: the same four
    engines and memory as the four-way run (27,792).
f4  f2 with 8,192 streams per engine (ladder 12,288 then 16,384) and a
    65,536-token step budget.
"""
import copy, json, os, sys
out = sys.argv[1]
os.makedirs(out, exist_ok=True)
IMAGE = "capsim/vllm-rocm:nightly-9bc16ae6-aiter-95d21128"
ENV = {"VLLM_ROCM_USE_AITER": "1", "HSA_NO_SCRATCH_RECLAIM": "1"}
SERVE = ["--stream-interval", "8", "--api-server-count", "4"]
def arm(model, per_engine, ladder, flags, per_gpu=1, gmu=0.95):
    c = {"engine": "vllm_cuda_multi", "model_id": model, "tp": 1, "replicas": 2, "max_model_len": 2048,
         "gpu_memory_utilization": gmu, "kv_cache_dtype": "fp8", "max_num_seqs": per_engine,
         "trust_remote_code": True, "vllm_gpu_image": IMAGE, "vllm_extra_env": ENV, "vllm_extra_flags": flags}
    if per_gpu > 1: c["replicas_per_gpu"] = per_gpu
    return {"workload": {"kind": "persona", "id": "headline_generation"}, "shape": {"input_tokens": 128, "output_tokens": 256},
            "ladder": ladder, "hold_s": 600, "new_run": True, "prefix_reuse": "industry", "custom": c}
BF16, FP8 = "LiquidAI/LFM2-24B-A2B", "LiquidAI/LFM2.5-24B-A2B-FP8"
arms = {
    "f1_dpx_2x1_lfm2_bf16": arm(BF16, 4096, [8192], SERVE),
    "f2_dpx_2x1_lfm2_bf16_step32k": arm(BF16, 4096, [8192], SERVE + ["--max-num-batched-tokens", "32768"]),
    "f3_dpx_2x2_lfm25fp8": arm(FP8, 1280, [5120], SERVE, per_gpu=2, gmu=0.97),
    "f4_dpx_2x1_lfm2_bf16_streams16k": arm(BF16, 8192, [12288, 16384], SERVE + ["--max-num-batched-tokens", "65536"]),
}
for name, a in arms.items():
    json.dump(a, open(f"{out}/{name}.json", "w"), indent=1)
print(sorted(os.listdir(out)))
