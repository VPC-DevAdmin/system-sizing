"""make_models_arms.py : the LFM2 mechanisms applied to the other models,
whole card (SPX), 10-minute holds at 128 in / 256 out.

Mechanisms: stream starts spread over about one request's duration; two
engines sharing the card; stream count per engine sized to the memory two
engines leave. References are spx/arms/a1..a4 (run_438 to run_441).
"""
import json, os
os.makedirs("spx4/arms", exist_ok=True)
def ref(name): return json.load(open(f"spx/arms/{name}.json"))
def save(name, a): json.dump(a, open(f"spx4/arms/{name}.json", "w"), indent=1)
SERVE = ["--stream-interval", "8", "--api-server-count", "4"]
def capture(sizes): return ["--compilation-config", json.dumps({"cudagraph_capture_sizes": sizes})]
def two(a, per_engine, spread, extra=()):
    b = json.loads(json.dumps(a))
    b["custom"]["replicas_per_gpu"] = 2
    b["custom"]["max_num_seqs"] = per_engine
    b["custom"]["vllm_extra_flags"] = b["custom"]["vllm_extra_flags"] + list(extra)
    b["ladder"] = [2 * per_engine]
    b["spread_s"] = spread
    return b

# LFM2.5 FP8: already two engines (40,855); add spread starts.
a = ref("a1_lfm25fp8_x2"); a["spread_s"] = 50
save("j1_lfm25fp8_x2_spread50", a)

# Gemma-4-26B FP8: one engine 16,724 at 1,536 streams (90 ms/token, 23 s a request).
a = ref("a3_gemma26_x1"); a["spread_s"] = 23
save("j2_gemma26_x1_spread23", a)
save("j3_gemma26_x2_768_spread23", two(ref("a3_gemma26_x1"), 768, 23))

# Qwen3.5-35B-A3B MXFP4: one engine 15,114 at 2,048 streams (134 ms/token, 34 s).
# Two engines leave about 39 GiB of session memory each (851 streams) once
# graph capture is cut, so 768 each.
a = ref("a2_qwen35a3b_x1"); a["spread_s"] = 34
save("j4_qwen35a3b_x1_spread34", a)
save("j5_qwen35a3b_x2_768_spread34", two(ref("a2_qwen35a3b_x1"), 768, 34,
     capture([1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 768])))

# Qwen3.8-27B MXFP4: one engine 4,389 at 1,024 streams (225 ms/token, 58 s).
# The reference had no serving settings; j7 adds them. Two engines hold
# about 354 streams each, so 320 each.
a = ref("a4_qwen38_x1"); a["spread_s"] = 58
save("j6_qwen38_x1_spread58", a)
b = json.loads(json.dumps(a)); b["custom"]["vllm_extra_flags"] += SERVE
save("j7_qwen38_x1_spread58_serve", b)
save("j8_qwen38_x2_320_spread58_serve", two(ref("a4_qwen38_x1"), 320, 58,
     SERVE + capture([1, 2, 4, 8, 16, 32, 64, 128, 256, 320])))
print(sorted(os.listdir("spx4/arms")))
