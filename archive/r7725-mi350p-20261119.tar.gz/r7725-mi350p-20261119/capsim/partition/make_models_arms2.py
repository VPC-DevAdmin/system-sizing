"""make_models_arms2.py : two-engine follow-ups with more streams.
The first two-engine runs left session memory unused (Qwen3.5 77%,
Qwen3.8 69%), so these fill it to about 91%."""
import json
def more(src, dst, per_engine):
    a = json.load(open(f"spx4/arms/{src}.json"))
    c = a["custom"]
    c["max_num_seqs"] = per_engine
    a["ladder"] = [2 * per_engine]
    i = c["vllm_extra_flags"].index("--compilation-config")
    sizes = json.loads(c["vllm_extra_flags"][i + 1])["cudagraph_capture_sizes"]
    sizes = [s for s in sizes if s < per_engine] + [per_engine]
    c["vllm_extra_flags"][i + 1] = json.dumps({"cudagraph_capture_sizes": sizes})
    json.dump(a, open(f"spx4/arms/{dst}.json", "w"), indent=1)
    print(dst, a["ladder"], c["max_num_seqs"], c["vllm_extra_flags"][i + 1])
more("j5_qwen35a3b_x2_768_spread34", "k1_qwen35a3b_x2_896_spread34", 896)
more("j8_qwen38_x2_320_spread58_serve", "k2_qwen38_x2_416_spread58_serve", 416)
