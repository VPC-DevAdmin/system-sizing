"""make_ref_arms.py OUT_DIR : whole-card (SPX) reference arms for the
partition test, each a 10-minute hold at 128 in / 256 out.

a*: the best whole-card configuration measured so far for each model.
b*: four engines on the unpartitioned card, each with a quarter of the
    memory share and of the stream count: the same layout the four-way
    partition run uses, so only the partitioning differs.
"""
import json, os, sys
out = sys.argv[1]
os.makedirs(out, exist_ok=True)
IMAGE = "capsim/vllm-rocm:nightly-9bc16ae6-aiter-95d21128"
ENV = {"VLLM_ROCM_USE_AITER": "1", "HSA_NO_SCRATCH_RECLAIM": "1"}
SERVE = ["--stream-interval", "8", "--api-server-count", "4"]
STATE = ["--mamba-ssm-cache-dtype", "bfloat16", "--attention-backend", "ROCM_AITER_FA"]
MODELS = {  # name: (model id, total streams, extra flags, trust_remote_code, engines in the "a" arm)
    "lfm25fp8": ("LiquidAI/LFM2.5-24B-A2B-FP8", 8192, SERVE, True, 2),
    "qwen35a3b": ("amd/Qwen3.5-35B-A3B-MXFP4", 2048, STATE + SERVE, False, 1),
    "gemma26": ("RedHatAI/gemma-4-26B-A4B-it-FP8-dynamic", 1536, SERVE, False, 1),
    "qwen38": ("amd/Qwen3.8-27B-Quark-AWQ-MXFP4", 1024, STATE, False, 1),
}
def arm(model, streams, flags, trust, engines):
    c = {"engine": "vllm_cuda_multi", "model_id": model, "tp": 1, "replicas": 1, "max_model_len": 2048,
         "gpu_memory_utilization": 0.95, "kv_cache_dtype": "fp8", "max_num_seqs": streams // engines,
         "vllm_gpu_image": IMAGE, "vllm_extra_env": ENV, "vllm_extra_flags": flags}
    if engines > 1: c["replicas_per_gpu"] = engines
    if trust: c["trust_remote_code"] = True
    return {"workload": {"kind": "persona", "id": "headline_generation"}, "shape": {"input_tokens": 128, "output_tokens": 256},
            "ladder": [streams], "hold_s": 600, "new_run": True, "prefix_reuse": "industry", "custom": c}
for i, (name, (model, streams, flags, trust, best)) in enumerate(MODELS.items(), 1):
    json.dump(arm(model, streams, flags, trust, best), open(f"{out}/a{i}_{name}_x{best}.json", "w"), indent=1)
    json.dump(arm(model, streams, flags, trust, 4), open(f"{out}/b{i}_{name}_x4.json", "w"), indent=1)
print(sorted(os.listdir(out)))
