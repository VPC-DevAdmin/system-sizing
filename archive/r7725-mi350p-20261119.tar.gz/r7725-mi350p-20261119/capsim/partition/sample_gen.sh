#!/usr/bin/env bash
# sample_gen.sh OUT SECONDS : every 2 s, the sum of generated and prompt tokens across all engine ports.
OUT=$1; END=$(( $(date +%s) + $2 ))
while [ $(date +%s) -lt $END ]; do
  g=0; p=0; r=0; w=0
  for port in $(ss -ltn | grep -oE ":9[0-9]{3}\b" | tr -d : | sort -u); do
    m=$(curl -s -m 2 localhost:$port/metrics)
    g=$(( g + $(echo "$m" | awk "/^vllm:generation_tokens_total\{/{s+=\$2} END{printf \"%d\", s}") ))
    p=$(( p + $(echo "$m" | awk "/^vllm:prompt_tokens_total\{/{s+=\$2} END{printf \"%d\", s}") ))
    r=$(( r + $(echo "$m" | awk "/^vllm:num_requests_running\{/{s+=\$2} END{printf \"%d\", s}") ))
    w=$(( w + $(echo "$m" | awk "/^vllm:num_requests_waiting\{/{s+=\$2} END{printf \"%d\", s}") ))
  done
  echo "$(date +%s.%N) $g $p $r $w" >> "$OUT"
  sleep 2
done
