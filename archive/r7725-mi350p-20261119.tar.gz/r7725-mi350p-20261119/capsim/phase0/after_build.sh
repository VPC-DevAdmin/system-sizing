#!/usr/bin/env bash
# When the AITER-main images are built, smoke-test them.
until grep -q "builds finished" /data/capsim/logs/phase0_build.log; do sleep 60; done
/data/capsim/phase0/run_arms.sh /data/capsim/phase0/smoke 2main
