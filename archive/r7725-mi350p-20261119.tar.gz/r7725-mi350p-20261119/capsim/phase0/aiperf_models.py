#!/usr/bin/env python3
"""AIPerf on the best recorded configuration of each top model, one campaign
after another. Each campaign attaches to the recorded run (its resolved
engine configuration), starts that engine fresh, and measures one load point
for 600 s after a 60 s warm-up with unique prompts. Results land in
runs/benchmarks/<id>; a line per campaign is appended to
/data/capsim/aiperf_models/summary.jsonl."""
import json, os, subprocess, sys, time, urllib.request

BASE = "http://localhost:8321"
OUT = "/data/capsim/aiperf_models"
RES = "/data/capsim/phase1c/results"
# (tag, result file, model, load point)
PLAN = [
    ("lagunaxs_sglang", "h2_sglang_stream8_lagunaxs.json", "poolside/Laguna-XS-2.1-FP8", 4096),
    ("gemma26_vllm", "c6g_vllm_srv_gemma26.json", "RedHatAI/gemma-4-26B-A4B-it-FP8-dynamic", 1536),
    ("qwen35a3b_vllm", "c6i_vllm_srv_qwen35a3b.json", "amd/Qwen3.5-35B-A3B-MXFP4", 2048),
    ("puzzle75b_vllm", "i1_vllm_puzzle75b_fp8.json", "nvidia/NVIDIA-Nemotron-Labs-3-Puzzle-75B-A9B-FP8", 1024),
    ("minimax_m27_vllm", "i2_vllm_minimax_m27_mxfp4.json", "amd/MiniMax-M2.7-MXFP4", 512),
]

def log(*a):
    print(time.strftime("%F %T"), *a, flush=True)

def call(path, body=None):
    req = urllib.request.Request(BASE + path, data=json.dumps(body).encode() if body is not None else None,
                                 headers={"content-type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=120) as r:
            return json.load(r)
    except urllib.error.HTTPError as e:
        return {"http_error": e.code, "detail": e.read().decode()[:500]}

def running():
    return bool((call("/api/status").get("active_run") or {}).get("running"))

def best_row(name, model):
    rows = [r for r in json.load(open(f"{RES}/{name}"))["results"]
            if r.get("model") == model and r.get("out_tok_s") and not r.get("error")]
    return max(rows, key=lambda r: r["out_tok_s"])

os.makedirs(OUT, exist_ok=True)
state_path = "/home/user/system-sizing/runs/roofline.json"
done = set()
if os.path.exists(f"{OUT}/summary.jsonl"):
    done = {json.loads(l)["tag"] for l in open(f"{OUT}/summary.jsonl")}
for tag, name, model, point in PLAN:
    if tag in done:
        continue
    while running():
        time.sleep(30)
    row = best_row(name, model)
    st = json.load(open(state_path))
    if not any(r.get("run_dir") == row["run_dir"] and r.get("out_tok_s") == row["out_tok_s"] for r in st["results"]):
        st["results"].append(row)
        json.dump(st, open(state_path, "w"), indent=1)
    rid = next((x["id"] for x in call("/api/roofline/benchmarks/results")["results"]
                if x["result"].get("run_dir") == row["run_dir"] and x["result"].get("out_tok_s") == row["out_tok_s"]), None)
    if rid is None:
        log(tag, "row not listed"); continue
    samp = subprocess.Popen(["/data/capsim/phase0/sample_counters.sh", f"{OUT}/{tag}"],
                            stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    r = call("/api/roofline/benchmarks", {"result_id": rid, "fresh": True, "spec": {
        "harnesses": ["aiperf"], "recipe": "sweep", "concurrency": [point], "duration_s": 600,
        "warmup_s": 60, "repetitions": 1, "input_tokens": 128, "output_tokens": 256, "dataset_size": 150000}})
    log(tag, "launch", json.dumps(r)[:300])
    cid = r.get("benchmark_id")
    if cid:
        time.sleep(30)
        while running():
            time.sleep(30)
        s = json.load(open(f"/home/user/system-sizing/runs/benchmarks/{cid}/state.json"))
        rec = {"tag": tag, "model": model, "point": point, "campaign": cid, "source_run": row["run_dir"],
               "capsim_out_tok_s": row["out_tok_s"], "outcome": s.get("outcome"), "error": s.get("error"),
               "attempts": [{k: a.get(k) for k in ("number", "outcome", "reasons", "metrics", "started_at", "ended_at")}
                            for a in s.get("attempts", [])]}
        open(f"{OUT}/summary.jsonl", "a").write(json.dumps(rec) + "\n")
        log(tag, s.get("outcome"), json.dumps((rec["attempts"] or [{}])[-1].get("metrics"))[:300])
    open(f"{OUT}/{tag}/stop", "w").close()
    samp.wait(timeout=30)
    time.sleep(20)
log("aiperf_models finished")
