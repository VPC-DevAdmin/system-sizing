"""Apply an open vLLM pull request's Python changes onto the installed nightly.

The PR diffs are against older bases, so `git apply --reject` places what
still fits and the few hunks that do not are placed here by anchor line.
Fails the image build if any hunk is left unplaced or a file stops compiling.
"""
import glob, os, py_compile, subprocess, sys

SP = "/usr/local/lib/python3.12/dist-packages"
pr = sys.argv[1]
os.chdir(SP)
args = ["git", "apply", "--reject", "--include=vllm/*"]
if pr == "65078":
    # The nightly already ships this package __init__; the PR only adds a header.
    args.append("--exclude=vllm/models/qwen3_5/__init__.py")
out = subprocess.run(args + [f"/p/pr{pr}.diff"], capture_output=True, text=True)
print(out.stderr[-3000:])
rejects = sorted(glob.glob("vllm/**/*.rej", recursive=True))
print("rejects:", rejects)


def insert(path, anchor, new, after=True, count=1):
    s = open(path).read()
    assert s.count(anchor) == count, (path, anchor, s.count(anchor))
    assert new.strip() not in s, (path, "already present")
    s = s.replace(anchor, anchor + new if after else new + anchor)
    open(path, "w").write(s)


if pr == "65078":
    assert rejects == ["vllm/envs.py.rej"], rejects
    insert("vllm/envs.py", "    VLLM_ROCM_USE_AITER_TRITON_GEMM: bool = True\n",
           "    VLLM_ROCM_MONO_DECODE: bool = False\n")
    insert("vllm/envs.py", '    "VLLM_ROCM_USE_AITER_TRITON_GEMM": lambda: (\n',
           '    "VLLM_ROCM_MONO_DECODE": lambda: (\n'
           '        os.getenv("VLLM_ROCM_MONO_DECODE", "False").lower() in ("true", "1")\n'
           "    ),\n", after=False)
    assert os.path.isfile("vllm/models/qwen3_5/amd/dense_mono.py")
    # The branch checks the dense MLP against Qwen2MoeMLP from a module the
    # nightly no longer has; Qwen3.5's MLP there is qwen3_moe.Qwen3MoeMLP.
    dm = "vllm/models/qwen3_5/amd/dense_mono.py"
    t = open(dm).read()
    old_imp = "from vllm.model_executor.models.qwen2_moe import Qwen2MoeMLP"
    assert t.count(old_imp) == 1
    open(dm, "w").write(t.replace(
        old_imp, "from vllm.model_executor.models.qwen3_moe import Qwen3MoeMLP as Qwen2MoeMLP"))
    assert "MONO" in open("vllm/model_executor/models/qwen3_5.py").read()
elif pr == "61902":
    assert rejects == ["vllm/compilation/passes/pass_manager.py.rej", "vllm/envs.py.rej"], rejects
    insert("vllm/envs.py", "    VLLM_ROCM_USE_AITER_MHA: bool = True\n",
           "    VLLM_ROCM_USE_AITER_FP4_ACT_QUANT_FUSION: bool = False\n")
    assert '"VLLM_ROCM_USE_AITER_FP4_ACT_QUANT_FUSION": lambda' in open("vllm/envs.py").read()
    pm = "vllm/compilation/passes/pass_manager.py"
    s = open(pm).read()
    old = "from vllm._aiter_ops import rocm_aiter_ops\n"
    assert s.count(old) == 1
    open(pm, "w").write(s.replace(old, "from vllm._aiter_ops import act_mxfp4_pass_registered, rocm_aiter_ops\n"))
    insert(pm, "                    self.passes += [RocmAiterSiluMulFp8GroupQuantFusionPass(config)]\n",
           "                # The asm MXFP4 GEMM it fuses into needs gfx950, so RDNA AITER\n"
           "                # (gfx12) never registers this pass.\n"
           "                if act_mxfp4_pass_registered(self.pass_config.fuse_act_quant):\n"
           "                    self.passes += [RocmAiterActMulMxfp4GemmFusionPass(config)]\n")
    assert "RocmAiterActMulMxfp4GemmFusionPass," in open(pm).read()
else:
    raise SystemExit(f"no recipe for PR {pr}")

for r in rejects:
    os.remove(r)
touched = [l.split()[-1][2:] for l in open(f"/p/pr{pr}.diff")
           if l.startswith("+++ b/vllm/") and l.strip().endswith(".py")]
touched = [f for f in touched if f != "vllm/models/qwen3_5/__init__.py"]
for f in touched:
    py_compile.compile(f, doraise=True)
print(f"PR {pr}: {len(touched)} files applied and compiled")
