#!/usr/bin/env bash
# big_dl.sh MODEL... : download each checkpoint to the /data2 overflow cache
# (up to 6 attempts; partial files resume) and link it into capsim's hub, so
# /data keeps its free space. capsim mounts the overflow root for the links.
OV=/data2/capsim/hf-overflow; HUB=/data/capsim/huggingface/hub
HF=/home/user/.local/share/uv/tools/capsim/bin/hf
mkdir -p $OV/hub
for m in "$@"; do
  d="models--${m//\//--}"
  for i in 1 2 3 4 5 6; do
    if HF_HOME=$OV $HF download "$m" --quiet >/dev/null 2>>/data/capsim/logs/big_dl_err.log; then
      [ -e "$HUB/$d" ] || ln -s "$OV/hub/$d" "$HUB/$d"
      echo "$(date '+%F %T') ok $m (try $i) $(du -shL $OV/hub/$d | cut -f1)"; break
    fi
    echo "$(date '+%F %T') try $i failed $m: $(tail -1 /data/capsim/logs/big_dl_err.log | cut -c1-160)"; sleep 20
  done
done
echo "$(date '+%F %T') downloads finished"
