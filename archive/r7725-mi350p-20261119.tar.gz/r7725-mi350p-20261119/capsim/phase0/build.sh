#!/usr/bin/env bash
# Phase 0: rebuild AITER at one pinned main commit in both engine images.
# CPU-only; pinned to the upper half of the cores so the running roofline keeps the rest.
cd /data/capsim/phase0
AITER=95d21128485c56fbadb37d5d158508985da5615b
V_BASE=vllm/vllm-openai-rocm:nightly-rocm100-9bc16ae6a34b1e0fe260e8d12b98568478bf38c3
S_BASE=rocm/sgl-dev:v0.5.23-rocm10-mi35x-20261115
log() { echo "$(date "+%F %T") $*"; }
until grep -q "pulls done" /data/capsim/logs/phase0_pull.log; do sleep 60; done
log "pulls done; building"
( DOCKER_BUILDKIT=0 docker build --network host --cpuset-cpus=96-143 -f Dockerfile.vllm-aiter \
    --build-arg BASE=$V_BASE --build-arg AITER_SHA=$AITER \
    -t capsim/vllm-rocm:nightly-9bc16ae6-aiter-95d21128 . > /data/capsim/logs/phase0_build_vllm.log 2>&1 \
  && log "vllm build ok" || log "vllm build FAILED" ) &
( DOCKER_BUILDKIT=0 docker build --network host --cpuset-cpus=144-191 -f Dockerfile.sglang-aiter \
    --build-arg BASE=$S_BASE --build-arg AITER_SHA=$AITER \
    -t capsim/sglang-rocm:20261115-aiter-95d21128 . > /data/capsim/logs/phase0_build_sglang.log 2>&1 \
  && log "sglang build ok" || log "sglang build FAILED" ) &
wait
log "builds finished"
docker images --format "{{.Repository}}:{{.Tag}} {{.ID}} {{.Size}}"
