#!/usr/bin/env bash
# Phase 0: technique images, each one open vLLM PR on top of the AITER-main image.
cd /data/capsim/phase0
BASE=capsim/vllm-rocm:nightly-9bc16ae6-aiter-95d21128
log() { echo "$(date "+%F %T") $*"; }
until docker image inspect $BASE >/dev/null 2>&1; do sleep 60; done
for pr in 65078 61902; do
  DOCKER_BUILDKIT=0 docker build -f Dockerfile.vllm-pr --build-arg BASE=$BASE --build-arg PR=$pr \
    -t $BASE-pr$pr . > /data/capsim/logs/phase0_build_pr$pr.log 2>&1 \
    && log "pr$pr image ok" || log "pr$pr image FAILED"
done
log "pr builds finished"
