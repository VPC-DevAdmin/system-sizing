"""Print every Phase 1 result: roofline cells and interactive sweeps."""
import glob, json, os, sys
D = sys.argv[1] if len(sys.argv) > 1 else "/data/capsim/phase1/results"
for f in sorted(glob.glob(D + "/*.json")):
    d = json.load(open(f)); name = os.path.basename(f)[:-5]
    if "results" in d:
        for r in d["results"]:
            if r.get("error"):
                print("%-24s ERROR %s" % (name, r["error"][:170])); continue
            print("%-24s conc %5s out %8.0f W %s tpot95 %s samples %s nc %s %s" % (
                name, r["concurrency"], r["out_tok_s"], r.get("gpu_power_w"), r.get("tpot_p95_ms"),
                r.get("samples"), r.get("no_content"), r.get("run_dir")))
    elif "rungs" in d:
        print("%-24s sweep %s | %s" % (name, [(g["concurrency"], g.get("out_tok_s"), g.get("tpot_p50_ms")) for g in d["rungs"]], str(d.get("stop_reason"))[:70]))
    else:
        print("%-24s %s" % (name, str(d)[:220]))
