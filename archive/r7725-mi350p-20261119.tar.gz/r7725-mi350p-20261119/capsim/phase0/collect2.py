"""Roofline arm results with every rung: conc:tok_s/in_flight[u]/watts."""
import json, glob, os, sys
os.chdir("/home/user/system-sizing")
for pat in sys.argv[1:]:
    for f in sorted(glob.glob(pat)):
        b = json.load(open(f))
        n = os.path.basename(f)[:-5].ljust(28)
        for c in b.get("results", []):
            if "out_tok_s" not in c:
                print(n, "cap", c.get("max_num_seqs"), "out", c.get("output_tokens"),
                      "ERROR", str(c.get("error"))[:200])
                continue
            try:
                d = json.load(open(c["run_dir"] + "/headline_sweep.json"))
                rg = " ".join("%s:%d/%d%s/%dW" % (
                    x.get("concurrency"), round(x.get("out_tok_s") or 0),
                    round(x.get("in_flight") or 0),
                    "" if x.get("steady_state") else "u",
                    round(x.get("gpu_power_w") or 0)) for x in d.get("rungs", []))
            except Exception as e:
                rg = str(e)
            print(n, "cap", c["max_num_seqs"], "out", c["output_tokens"],
                  "best", round(c["out_tok_s"]), "n", c["samples"], "|", rg)
