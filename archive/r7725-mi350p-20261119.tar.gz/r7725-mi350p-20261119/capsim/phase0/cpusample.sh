#!/usr/bin/env bash
# One line a minute: GPU power/activity and the busiest processes.
for i in $(seq ${1:-40}); do
  p=$(amd-smi metric -g 0 --usage --power 2>/dev/null | grep -iE "GFX_ACTIVITY|SOCKET_POWER" | tr -s " " | tr "\n" " ")
  t=$(top -b -n 2 -d 3 -w 160 -c | awk "/^top -/{n++} n==2" | sed -n 8,12p | awk "{printf \"%s%%:%s \", \$9, \$12}")
  echo "$(date +%T) $p| $t"
  sleep 55
done
