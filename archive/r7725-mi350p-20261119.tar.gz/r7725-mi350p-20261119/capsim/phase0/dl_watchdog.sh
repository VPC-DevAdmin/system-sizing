#!/usr/bin/env bash
# Restarts a stalled hf download: if the overflow cache has not grown for
# three minutes while a download is running, kill it so big_dl.sh retries
# (partial files resume). The lab's route to huggingface.co hangs at times.
OV=/data2/capsim/hf-overflow/hub
while pgrep -f "[b]ig_dl.sh" >/dev/null; do
  a=$(du -sm $OV | cut -f1); sleep 180; b=$(du -sm $OV | cut -f1)
  if [ "$a" = "$b" ]; then
    for pid in $(pgrep -f "bin/[h]f download"); do kill "$pid"; done
    echo "$(date '+%F %T') stalled at ${b} MB; restarted"
  fi
done
echo "$(date '+%F %T') no downloads left"
