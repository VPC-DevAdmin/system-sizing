import re
for name in ("Dockerfile.vllm-aiter", "Dockerfile.sglang-aiter"):
    s = open(name).read()
    # Drop the MEGA_MOE skip: the failure came from building the old AITER, not from main.
    s = re.sub(r"# AITER main pins flydsl 0\.5\.0.*?common\.py\n", "", s, flags=re.S)
    # The SGLang base image sets ENV AITER_COMMIT (its October pin), and ENV beats ARG,
    # so use a name the base image does not define.
    s = s.replace("AITER_COMMIT", "AITER_SHA")
    if "sglang" in name:
        s = s.replace("ENV AITER_SHA=${AITER_SHA}\n", "ENV AITER_COMMIT=${AITER_SHA}\n")
        s = s.replace("&& git clean -fdxq && git submodule update",
                      "&& test \"$(git rev-parse HEAD)\" = \"${AITER_SHA}\" \\\n && git clean -fdxq && git submodule update")
    open(name, "w").write(s)
s = open("build.sh").read().replace("--build-arg AITER_COMMIT=", "--build-arg AITER_SHA=")
open("build.sh", "w").write(s)
print(open("Dockerfile.sglang-aiter").read())
