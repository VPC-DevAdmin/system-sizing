"""First runs of the newer candidate models on both engines (128 in / 256 out,
cap 1024). c1 = vLLM nightly + AITER main, AITER on. c2 = SGLang daily + AITER
main. Models with linear-attention or state-space layers get half-precision
recurrent state, the setting that paid on Qwen3.8-27B."""
import json, os, sys
out = sys.argv[1]
V = "capsim/vllm-rocm:nightly-9bc16ae6-aiter-95d21128"
S = "capsim/sglang-rocm:20261115-aiter-95d21128"
AITER = {"VLLM_ROCM_USE_AITER": "1", "HSA_NO_SCRATCH_RECLAIM": "1"}
# key -> (model id, keeps recurrent state)
MODELS = {
    "flashnext": ("amd/Qwen3.8-Flash-Next-Quark-TokenPLE-AWQ-UINT4", True),
    "lightning": ("RedHatAI/NVIDIA-Nemotron-3.5-Lightning-30B-A3B-FP8", True),
    "northmini": ("CohereLabs/North-Mini-Code-1.0-fp8", False),
    "lagunaxs": ("poolside/Laguna-XS-2.1-FP8", False),
    "lfm2": ("LiquidAI/LFM2-24B-A2B", False),
    "raon": ("KRAFTON/Raon-1-mini-preview", False),
    "instella": ("amd/Instella-MoE-16B-A3B-SFT", False),
    "museglimmer": ("amd/Muse-Glimmer-30B-w8a8-llmcompressor", False),
    "step35flash": ("amd/Step-3.5-Flash-MXFP4", False),
    "arete27": ("NousResearch/Arete-27B", True),
    "qwen36_27": ("Qwen/Qwen3.6-27B-FP8", True),
    "nemo3super": ("nvidia/NVIDIA-Nemotron-3-Super-120B-A12B-FP8", True),
}
os.makedirs(f"{out}/arms", exist_ok=True)
for key, (model, state) in MODELS.items():
    for name, engine, custom in (
        ("c1_vllm", "vllm_cuda_multi",
         {"vllm_gpu_image": V, "vllm_extra_env": AITER,
          "vllm_extra_flags": ["--trust-remote-code"]
          + (["--mamba-ssm-cache-dtype", "bfloat16"] if state else [])}),
        ("c2_sglang", "sglang_cuda",
         {"sglang_image": S,
          "sglang_extra_flags": ["--trust-remote-code"]
          + (["--mamba-ssm-dtype", "bfloat16", "--mamba-full-memory-ratio", "4"] if state else [])}),
    ):
        doc = {"workload": {"kind": "roofline", "spec": {
                   "models": [model], "engines": [engine], "max_num_seqs": [1024],
                   "output_tokens": [256], "input_tokens": 128, "confirm_winners": False}},
               "new_run": True, "custom": {"engine": engine, **custom}}
        json.dump(doc, open(f"{out}/arms/{name}_{key}.json", "w"), indent=1)
print(len(os.listdir(f"{out}/arms")), "arms")
