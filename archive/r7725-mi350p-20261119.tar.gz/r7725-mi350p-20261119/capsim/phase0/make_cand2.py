"""Follow-ups on the newer models that ran (128 in / 256 out).

c3 = lift the limit each first run hit: a 2048 cap where the run was
queue-bound at 1024 with cache to spare, AITER flash attention on the
hybrid Lightning, SGLang's unified attention for North-Mini's sliding window.
c4 = serving settings on LFM2, whose GPU power fell as streams rose (a
host-side limit): batched streaming, more API server processes, both.
"""
import json, os, sys
out = sys.argv[1]
V = "capsim/vllm-rocm:nightly-9bc16ae6-aiter-95d21128"
S = "capsim/sglang-rocm:20261115-aiter-95d21128"
AITER = {"VLLM_ROCM_USE_AITER": "1", "HSA_NO_SCRATCH_RECLAIM": "1"}
TRC = ["--trust-remote-code"]
def arm(name, engine, model, caps, custom):
    doc = {"workload": {"kind": "roofline", "spec": {
               "models": [model], "engines": [engine], "max_num_seqs": caps,
               "output_tokens": [256], "input_tokens": 128, "confirm_winners": False}},
           "new_run": True, "custom": {"engine": engine, **custom}}
    json.dump(doc, open(f"{out}/arms/{name}.json", "w"), indent=1)
def vllm(name, model, caps, flags):
    arm(name, "vllm_cuda_multi", model, caps,
        {"vllm_gpu_image": V, "vllm_extra_env": AITER, "vllm_extra_flags": TRC + flags})
LAG, LFM, NOR = "poolside/Laguna-XS-2.1-FP8", "LiquidAI/LFM2-24B-A2B", "CohereLabs/North-Mini-Code-1.0-fp8"
LIG = "RedHatAI/NVIDIA-Nemotron-3.5-Lightning-30B-A3B-FP8"
SI, AS = ["--stream-interval", "8"], ["--api-server-count", "4"]
vllm("c4a_vllm_stream8_lfm2", LFM, [1024], SI)
vllm("c4b_vllm_api4_lfm2", LFM, [1024], AS)
vllm("c4c_vllm_stream8_api4_lfm2", LFM, [1024, 2048], SI + AS)
vllm("c3_vllm_cap2048_lagunaxs", LAG, [2048], [])
arm("c3_sglang_cap2048_lagunaxs", "sglang_cuda", LAG, [2048],
    {"sglang_image": S, "sglang_extra_flags": TRC})
vllm("c3_vllm_fa_lightning", LIG, [1024, 2048],
     ["--mamba-ssm-cache-dtype", "bfloat16", "--attention-backend", "ROCM_AITER_FA"])
arm("c3_sglang_unified_northmini", "sglang_cuda", NOR, [1024],
    {"sglang_image": S, "sglang_extra_flags": TRC,
     "sglang_extra_env": {"SGLANG_USE_AITER_UNIFIED_ATTN": "1"}})
print(sorted(f for f in os.listdir(f"{out}/arms") if f.startswith(("c3", "c4"))))
