"""Serving settings on every model near the host-side limit (128 in / 256 out).

LFM2 went from 15,103 to 24,068 tok/s with batched streaming
(--stream-interval 8), four API server processes and a 2048 cap, and its
GPU was still at 334 W. c5 = the same settings on the other fast models,
and a wider cap and more server processes on LFM2.
"""
import json, os, sys
out = sys.argv[1]
V = "capsim/vllm-rocm:nightly-9bc16ae6-aiter-95d21128"
S = "capsim/sglang-rocm:20261115-aiter-95d21128"
AITER = {"VLLM_ROCM_USE_AITER": "1", "HSA_NO_SCRATCH_RECLAIM": "1"}
TRC = ["--trust-remote-code"]
SRV = ["--stream-interval", "8", "--api-server-count", "4"]
SRV8 = ["--stream-interval", "16", "--api-server-count", "8"]
HYB = ["--mamba-ssm-cache-dtype", "bfloat16", "--attention-backend", "ROCM_AITER_FA"]
def arm(name, engine, model, caps, custom):
    doc = {"workload": {"kind": "roofline", "spec": {
               "models": [model], "engines": [engine], "max_num_seqs": caps,
               "output_tokens": [256], "input_tokens": 128, "confirm_winners": False}},
           "new_run": True, "custom": {"engine": engine, **custom}}
    json.dump(doc, open(f"{out}/arms/{name}.json", "w"), indent=1)
def vllm(name, model, caps, flags, env=AITER):
    arm(name, "vllm_cuda_multi", model, caps,
        {"vllm_gpu_image": V, "vllm_extra_env": env, "vllm_extra_flags": flags})
def sglang(name, model, caps, flags, env):
    arm(name, "sglang_cuda", model, caps,
        {"sglang_image": S, "sglang_extra_flags": TRC + flags, "sglang_extra_env": env})
LAG, LFM, NOR = "poolside/Laguna-XS-2.1-FP8", "LiquidAI/LFM2-24B-A2B", "CohereLabs/North-Mini-Code-1.0-fp8"
UNI = {"SGLANG_USE_AITER_UNIFIED_ATTN": "1"}
vllm("c5a_vllm_srv_lfm2", LFM, [4096], TRC + SRV)
vllm("c5b_vllm_srv8_lfm2", LFM, [2048, 4096], TRC + SRV8)
vllm("c5c_vllm_srv_northmini", NOR, [1024, 2048], TRC + SRV)
vllm("c5d_vllm_srv_lagunaxs", LAG, [1024, 2048], TRC + SRV)
sglang("c5e_sglang_unified_northmini", NOR, [2048], [], UNI)
sglang("c5f_sglang_unified_stream8_northmini", NOR, [1024, 2048], ["--stream-interval", "8"], UNI)
sglang("c5g_sglang_unified_lagunaxs", LAG, [1024], [], UNI)
vllm("c5h_vllm_srv_gemma26", "RedHatAI/gemma-4-26B-A4B-it-FP8-dynamic", [768, 1024], SRV)
vllm("c5i_vllm_srv_glm47flash", "zai-org/GLM-4.7-Flash", [2048], SRV, env={})
vllm("c5j_vllm_srv_qwen36a3b", "Qwen/Qwen3.6-35B-A3B-FP8", [2048], HYB + SRV)
vllm("c5k_vllm_srv_lightning", "RedHatAI/NVIDIA-Nemotron-3.5-Lightning-30B-A3B-FP8", [2048],
     TRC + ["--mamba-ssm-cache-dtype", "bfloat16"] + SRV)
print(sorted(f for f in os.listdir(f"{out}/arms") if f.startswith("c5")))
