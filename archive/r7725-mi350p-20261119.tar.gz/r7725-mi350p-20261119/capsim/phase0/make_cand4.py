"""Second round of serving settings (c6, 128 in / 256 out) and the shape
search redone on the serving settings (x arms).

With batched streaming and four API server processes the fast models moved
up: LFM2 29,806 (cap 4096, GPU 356 W, vLLM engine core at 100% of a core),
North-Mini 25,211 on SGLang, Laguna-XS 19,477 on vLLM (cap 2048). c6 widens
the cap where the peak was at the widest one tried and puts batched
streaming on the SGLang cells that trailed. x = input 32 and output 1024 at
each leader's best cell.
"""
import json, os, sys
c, s = sys.argv[1], sys.argv[2]
V = "capsim/vllm-rocm:nightly-9bc16ae6-aiter-95d21128"
S = "capsim/sglang-rocm:20261115-aiter-95d21128"
AITER = {"VLLM_ROCM_USE_AITER": "1", "HSA_NO_SCRATCH_RECLAIM": "1"}
TRC = ["--trust-remote-code"]
SRV = ["--stream-interval", "8", "--api-server-count", "4"]
ST8 = ["--stream-interval", "8"]
HYB = ["--mamba-ssm-cache-dtype", "bfloat16", "--attention-backend", "ROCM_AITER_FA"]
SHYB = ["--mamba-ssm-dtype", "bfloat16", "--mamba-full-memory-ratio", "4"]
UNI = {"SGLANG_USE_AITER_UNIFIED_ATTN": "1"}
def arm(out, name, engine, model, caps, custom, outs=(256,), inp=128):
    doc = {"workload": {"kind": "roofline", "spec": {
               "models": [model], "engines": [engine], "max_num_seqs": caps,
               "output_tokens": list(outs), "input_tokens": inp, "confirm_winners": False}},
           "new_run": True, "custom": {"engine": engine, **custom}}
    json.dump(doc, open(f"{out}/arms/{name}.json", "w"), indent=1)
def vl(flags, env=AITER):
    return "vllm_cuda_multi", {"vllm_gpu_image": V, "vllm_extra_env": env, "vllm_extra_flags": flags}
def sg(flags, env):
    d = {"sglang_image": S, "sglang_extra_flags": TRC + flags}
    if env: d["sglang_extra_env"] = env
    return "sglang_cuda", d
LAG, LFM, NOR = "poolside/Laguna-XS-2.1-FP8", "LiquidAI/LFM2-24B-A2B", "CohereLabs/North-Mini-Code-1.0-fp8"
GEM, GLM = "RedHatAI/gemma-4-26B-A4B-it-FP8-dynamic", "zai-org/GLM-4.7-Flash"
LIG = "RedHatAI/NVIDIA-Nemotron-3.5-Lightning-30B-A3B-FP8"
C6 = [
 ("c6a_vllm_srv_lfm2", LFM, [8192], vl(TRC + SRV)),
 ("c6b_vllm_srv_async_lfm2", LFM, [4096], vl(TRC + SRV + ["--async-scheduling"])),
 ("c6c_sglang_unified_stream8_northmini", NOR, [4096], sg(ST8, UNI)),
 ("c6d_vllm_srv_northmini", NOR, [4096], vl(TRC + SRV)),
 ("c6e_vllm_srv_lagunaxs", LAG, [4096], vl(TRC + SRV)),
 ("c6f_sglang_stream8_lagunaxs", LAG, [1024, 2048], sg(ST8, None)),
 ("c6g_vllm_srv_gemma26", GEM, [1536, 2048], vl(SRV)),
 ("c6h_vllm_srv_glm47flash", GLM, [4096], vl(SRV, env={})),
 ("c6i_vllm_srv_qwen35a3b", "amd/Qwen3.5-35B-A3B-MXFP4", [2048], vl(HYB + SRV)),
 ("c6j_vllm_srv_codernext", "amd/Qwen3-Coder-Next-MXFP4", [2048], vl(HYB + SRV)),
 ("c6k_sglang_stream8_lightning", LIG, [1024, 2048], sg(SHYB + ST8, None)),
 ("c6l_sglang_stream8_qwen36a3b", "Qwen/Qwen3.6-35B-A3B-FP8", [2048], sg(SHYB + ST8, None)),
]
for name, model, caps, (engine, custom) in C6:
    arm(c, name, engine, model, caps, custom)
X = [
 ("lfm2", LFM, [4096], vl(TRC + SRV)),
 ("northmini", NOR, [2048], sg(ST8, UNI)),
 ("lagunaxs", LAG, [2048], vl(TRC + SRV)),
 ("gemma26", GEM, [1024], vl(SRV)),
]
for i, (key, model, caps, (engine, custom)) in enumerate(X):
    arm(s, f"x{i}a_in32_{key}", engine, model, caps, custom, outs=(256, 1024), inp=32)
    arm(s, f"x{i}b_out1024_{key}", engine, model, caps, custom, outs=(1024,), inp=128)
print(sorted(f for f in os.listdir(f"{c}/arms") if f.startswith("c6")))
print(sorted(f for f in os.listdir(f"{s}/arms") if f.startswith("x")))
