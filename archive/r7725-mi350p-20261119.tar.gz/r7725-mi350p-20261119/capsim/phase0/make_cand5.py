"""Two vLLM engine processes on the one GPU (d arms, 128 in / 256 out).

LFM2 on one engine process levels off at 28 to 30k tok/s with the engine
core at 100% of a host core and the GPU at about 357 W of 450 (caps 4096
and 8192, async scheduling set or not). Its weights are 44 GiB, so two
processes fit the 144 GB card with about 21 GiB of KV cache each; three do
not. The cap is per process.
"""
import json, os, sys
out = sys.argv[1]
V = "capsim/vllm-rocm:nightly-9bc16ae6-aiter-95d21128"
AITER = {"VLLM_ROCM_USE_AITER": "1", "HSA_NO_SCRATCH_RECLAIM": "1"}
SRV = ["--trust-remote-code", "--stream-interval", "8", "--api-server-count", "4"]
def arm(name, model, caps, per_gpu, flags=SRV, env=AITER):
    doc = {"workload": {"kind": "roofline", "spec": {
               "models": [model], "engines": ["vllm_cuda_multi"], "max_num_seqs": caps,
               "output_tokens": [256], "input_tokens": 128, "confirm_winners": False}},
           "new_run": True,
           "custom": {"engine": "vllm_cuda_multi", "vllm_gpu_image": V,
                      "vllm_extra_env": env, "vllm_extra_flags": flags,
                      "replicas_per_gpu": per_gpu}}
    json.dump(doc, open(f"{out}/arms/{name}.json", "w"), indent=1)
arm("d1_vllm_srv_x2_lfm2", "LiquidAI/LFM2-24B-A2B", [2048, 4096], 2)
print(sorted(f for f in os.listdir(f"{out}/arms") if f.startswith("d")))
