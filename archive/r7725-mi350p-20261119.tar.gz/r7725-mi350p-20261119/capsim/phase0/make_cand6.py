"""Arms that act on the 2026-11-16 profiles (e arms, 128 in / 256 out).

The profiles put 19 to 42% of GPU time in vLLM's own paged-attention kernel
on LFM2, Gemma-4-26B and Laguna-XS, where AITER's flash attention was never
selected: e1-e4 select it. e5 repeats the two-engine LFM2 peak. e6-e8 are
LFM2.5-24B-A2B FP8 (half the weight bytes) on one, two and three engines.
g1 is the first load of Qwen3.5-122B-A10B MXFP4.
"""
import json, os, sys
out = sys.argv[1]
V = "capsim/vllm-rocm:nightly-9bc16ae6-aiter-95d21128"
AITER = {"VLLM_ROCM_USE_AITER": "1", "HSA_NO_SCRATCH_RECLAIM": "1"}
TRC = ["--trust-remote-code"]
SRV = ["--stream-interval", "8", "--api-server-count", "4"]
FA = ["--attention-backend", "ROCM_AITER_FA"]
HYB = ["--mamba-ssm-cache-dtype", "bfloat16"] + FA
TEXT = ["--limit-mm-per-prompt", '{"image": 0, "audio": 0, "video": 0}']
def arm(name, model, caps, flags, per_gpu=1):
    custom = {"engine": "vllm_cuda_multi", "vllm_gpu_image": V, "vllm_extra_env": AITER,
              "vllm_extra_flags": flags}
    if per_gpu > 1:
        custom["replicas_per_gpu"] = per_gpu
    doc = {"workload": {"kind": "roofline", "spec": {
               "models": [model], "engines": ["vllm_cuda_multi"], "max_num_seqs": caps,
               "output_tokens": [256], "input_tokens": 128, "confirm_winners": False}},
           "new_run": True, "custom": custom}
    json.dump(doc, open(f"{out}/arms/{name}.json", "w"), indent=1)
LFM, LFM25 = "LiquidAI/LFM2-24B-A2B", "LiquidAI/LFM2.5-24B-A2B-FP8"
arm("e1_vllm_fa_lagunaxs", "poolside/Laguna-XS-2.1-FP8", [4096], TRC + SRV + FA)
arm("e2_vllm_fa_northmini", "CohereLabs/North-Mini-Code-1.0-fp8", [4096], TRC + SRV + FA)
arm("e3_vllm_fa_x2_lfm2", LFM, [4096], TRC + SRV + FA, per_gpu=2)
arm("e4_vllm_fa_text_gemma26", "RedHatAI/gemma-4-26B-A4B-it-FP8-dynamic", [1536], SRV + FA + TEXT)
arm("e5_vllm_x2_lfm2_repeat", LFM, [4096], TRC + SRV, per_gpu=2)
arm("e6_vllm_lfm25fp8", LFM25, [4096], TRC + SRV)
arm("e7_vllm_x2_lfm25fp8", LFM25, [4096], TRC + SRV, per_gpu=2)
arm("e8_vllm_x3_lfm25fp8", LFM25, [4096], TRC + SRV, per_gpu=3)
arm("g1_vllm_qwen35_122b_mxfp4", "olka-fi/Qwen3.5-122B-A10B-MXFP4", [512, 1024], SRV + HYB)
print(sorted(f for f in os.listdir(f"{out}/arms") if f[0] in "eg"))
