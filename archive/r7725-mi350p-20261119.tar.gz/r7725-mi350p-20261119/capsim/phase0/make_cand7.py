"""Next iteration (h arms) and first loads of the larger models (i arms).

h1: Gemma on vLLM's ROCm paged-attention kernel (AITER flash attention
    rejects its head size; the default kernel is 42% of its GPU time).
h2: Laguna-XS on SGLang at a 4096 cap (26,100 at 2048 and still rising).
i*: first loads, 128 in / 256 out. The two community "MXFP4" checkpoints
    are compressed-tensors 4-bit, which this vLLM build sends to a kernel
    it does not have on ROCm, so they are tried on SGLang only.
"""
import json, os, sys
out = sys.argv[1]
V = "capsim/vllm-rocm:nightly-9bc16ae6-aiter-95d21128"
S = "capsim/sglang-rocm:20261115-aiter-95d21128"
AITER = {"VLLM_ROCM_USE_AITER": "1", "HSA_NO_SCRATCH_RECLAIM": "1"}
TRC = ["--trust-remote-code"]
SRV = ["--stream-interval", "8", "--api-server-count", "4"]
ST8 = ["--stream-interval", "8"]
BF = ["--mamba-ssm-cache-dtype", "bfloat16"]
FA = ["--attention-backend", "ROCM_AITER_FA"]
SHYB = ["--mamba-ssm-dtype", "bfloat16", "--mamba-full-memory-ratio", "4"]
def arm(name, engine, model, caps, custom):
    doc = {"workload": {"kind": "roofline", "spec": {
               "models": [model], "engines": [engine], "max_num_seqs": caps,
               "output_tokens": [256], "input_tokens": 128, "confirm_winners": False}},
           "new_run": True, "custom": {"engine": engine, **custom}}
    json.dump(doc, open(f"{out}/arms/{name}.json", "w"), indent=1)
def vllm(name, model, caps, flags, gmu=None):
    c = {"vllm_gpu_image": V, "vllm_extra_env": AITER, "vllm_extra_flags": flags}
    if gmu: c["gpu_memory_utilization"] = gmu
    arm(name, "vllm_cuda_multi", model, caps, c)
def sglang(name, model, caps, flags):
    arm(name, "sglang_cuda", model, caps, {"sglang_image": S, "sglang_extra_flags": TRC + flags})
vllm("h1_vllm_rocmattn_gemma26", "RedHatAI/gemma-4-26B-A4B-it-FP8-dynamic", [1536],
     SRV + ["--attention-backend", "ROCM_ATTN"])
sglang("h2_sglang_stream8_lagunaxs", "poolside/Laguna-XS-2.1-FP8", [4096], ST8)
vllm("i1_vllm_puzzle75b_fp8", "nvidia/NVIDIA-Nemotron-Labs-3-Puzzle-75B-A9B-FP8", [512, 1024], TRC + SRV + BF)
vllm("i2_vllm_minimax_m27_mxfp4", "amd/MiniMax-M2.7-MXFP4", [256, 512], TRC + SRV, gmu=0.98)
vllm("i3_vllm_step35flash_mxfp4", "amd/Step-3.5-Flash-MXFP4", [256, 512], TRC + SRV, gmu=0.98)
vllm("i4_vllm_qwen35_122b_fp8", "Qwen/Qwen3.5-122B-A10B-FP8", [256], SRV + BF + FA, gmu=0.98)
sglang("i5_sglang_lagunas_mxfp4", "olka-fi/Laguna-S-2.1-MXFP4", [512], ST8)
sglang("i6_sglang_qwen35_122b_mxfp4", "olka-fi/Qwen3.5-122B-A10B-MXFP4", [512], SHYB + ST8)
print(sorted(f for f in os.listdir(f"{out}/arms") if f[0] in "hi"))
