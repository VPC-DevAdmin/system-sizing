"""k arms: MiniMax-M2.7 (229B) with AITER flash attention and a slightly
wider cap (its 20 GiB KV cache holds about 500 requests of this shape), and
Gemma on vLLM's ROCm paged-attention kernel in text-only mode."""
import json, os, sys
out = sys.argv[1]
V = "capsim/vllm-rocm:nightly-9bc16ae6-aiter-95d21128"
AITER = {"VLLM_ROCM_USE_AITER": "1", "HSA_NO_SCRATCH_RECLAIM": "1"}
SRV = ["--stream-interval", "8", "--api-server-count", "4"]
def vllm(name, model, caps, flags, gmu=None):
    c = {"engine": "vllm_cuda_multi", "vllm_gpu_image": V, "vllm_extra_env": AITER, "vllm_extra_flags": flags}
    if gmu: c["gpu_memory_utilization"] = gmu
    doc = {"workload": {"kind": "roofline", "spec": {
               "models": [model], "engines": ["vllm_cuda_multi"], "max_num_seqs": caps,
               "output_tokens": [256], "input_tokens": 128, "confirm_winners": False}},
           "new_run": True, "custom": c}
    json.dump(doc, open(f"{out}/arms/{name}.json", "w"), indent=1)
vllm("k1_vllm_fa_minimax_m27", "amd/MiniMax-M2.7-MXFP4", [512, 640],
     ["--trust-remote-code"] + SRV + ["--attention-backend", "ROCM_AITER_FA"], gmu=0.98)
vllm("k2_vllm_rocmattn_text_gemma26", "RedHatAI/gemma-4-26B-A4B-it-FP8-dynamic", [1536],
     SRV + ["--attention-backend", "ROCM_ATTN", "--limit-mm-per-prompt", '{"image": 0, "audio": 0, "video": 0}'])
print(sorted(f for f in os.listdir(f"{out}/arms") if f[0] == "k"))
