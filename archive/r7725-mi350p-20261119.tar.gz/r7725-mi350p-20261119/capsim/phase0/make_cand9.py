"""m arm: MiniMax-M2.7 at 1k in / 1k out, the shape the XE7740 efficiency
sweep used for the same model (FP8, vLLM, four cards per copy)."""
import json, os, sys
out = sys.argv[1]
V = "capsim/vllm-rocm:nightly-9bc16ae6-aiter-95d21128"
doc = {"workload": {"kind": "roofline", "spec": {
           "models": ["amd/MiniMax-M2.7-MXFP4"], "engines": ["vllm_cuda_multi"],
           "max_num_seqs": [64, 96, 128], "output_tokens": [1024], "input_tokens": 1024,
           "confirm_winners": False}},
       "new_run": True,
       "custom": {"engine": "vllm_cuda_multi", "vllm_gpu_image": V, "max_model_len": 4096,
                  "gpu_memory_utilization": 0.98,
                  "vllm_extra_env": {"VLLM_ROCM_USE_AITER": "1", "HSA_NO_SCRATCH_RECLAIM": "1"},
                  "vllm_extra_flags": ["--trust-remote-code", "--stream-interval", "8", "--api-server-count", "4"]}}
json.dump(doc, open(f"{out}/arms/m1_vllm_minimax_m27_1k1k.json", "w"), indent=1)
print("m1 written")
