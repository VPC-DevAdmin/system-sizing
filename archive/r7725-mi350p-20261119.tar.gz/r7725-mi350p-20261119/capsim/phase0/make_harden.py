"""Hardening runs for the two-engine LFM2-24B-A2B figure (same image and
flags as run_393). Each arm is a fresh engine start.

r1a-c  8,192 streams held 10 minutes (the headline: mean and range of three)
r2     fixed batch of 50,000 requests, client total against engine total
r3     r1 with prefix reuse off (no shared prompt, engine cache disabled)
r4a-c  scored task set: bf16 KV idle, fp8 KV idle, fp8 KV under 8,192 streams
r5     r1 at 1,024 in / 1,024 out
"""
import json, os, sys
out = sys.argv[1]
os.makedirs(f"{out}/arms", exist_ok=True)
V = "capsim/vllm-rocm:nightly-9bc16ae6-aiter-95d21128"
def arm(name, *, hold=None, batch=None, reuse="industry", ladder=(8192,), kv="fp8",
        shape=(128, 256), max_len=2048):
    doc = {"workload": {"kind": "persona", "id": "headline_generation"},
           "shape": {"input_tokens": shape[0], "output_tokens": shape[1]},
           "ladder": list(ladder), "new_run": True, "prefix_reuse": reuse,
           "custom": {"engine": "vllm_cuda_multi", "model_id": "LiquidAI/LFM2-24B-A2B",
                      "tp": 1, "replicas": 1, "replicas_per_gpu": 2,
                      "max_model_len": max_len, "gpu_memory_utilization": 0.95,
                      "kv_cache_dtype": kv, "max_num_seqs": 4096, "trust_remote_code": True,
                      "vllm_gpu_image": V,
                      "vllm_extra_env": {"VLLM_ROCM_USE_AITER": "1", "HSA_NO_SCRATCH_RECLAIM": "1"},
                      "vllm_extra_flags": ["--stream-interval", "8", "--api-server-count", "4"]}}
    if hold: doc["hold_s"] = hold
    if batch: doc["batch_requests"] = batch
    json.dump(doc, open(f"{out}/arms/{name}.json", "w"), indent=1)
for s in "abc":
    arm(f"r1{s}_hold600", hold=600)
arm("r2_batch50k", batch=50000)
arm("r3_hold600_reuse_off", hold=600, reuse="off")
arm("r4a_quality_bf16kv_idle", hold=180, ladder=(1,), kv="auto")
arm("r4b_quality_fp8kv_idle", hold=180, ladder=(1,))
arm("r4c_quality_fp8kv_loaded", hold=300)
arm("r5_hold600_1k1k", hold=600, shape=(1024, 1024), max_len=4096)
print(sorted(os.listdir(f"{out}/arms")))
