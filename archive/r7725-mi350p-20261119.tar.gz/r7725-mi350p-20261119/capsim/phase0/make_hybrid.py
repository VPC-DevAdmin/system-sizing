"""Hybrid-state arms for Qwen3.8-27B MXFP4 (cap 1024, 128 in / 256 out).

Both engines cap this model's concurrency by its recurrent-state cache
(SGLang: 71 running requests; vLLM: about 300), so these arms shrink the
state and give it more of the card before any kernel setting matters.
"""
import json, os, sys
out = sys.argv[1]
V = "capsim/vllm-rocm:nightly-9bc16ae6-aiter-95d21128"
S = "capsim/sglang-rocm:20261115-aiter-95d21128"
MODEL = "amd/Qwen3.8-27B-Quark-AWQ-MXFP4"
AITER = {"VLLM_ROCM_USE_AITER": "1", "HSA_NO_SCRATCH_RECLAIM": "1"}
os.makedirs(f"{out}/arms", exist_ok=True)

def arm(name, engine, custom, cap=1024):
    doc = {"workload": {"kind": "roofline", "spec": {
               "models": [MODEL], "engines": [engine], "max_num_seqs": [cap],
               "output_tokens": [256], "input_tokens": 128, "confirm_winners": False}},
           "new_run": True, "custom": {"engine": engine, **custom}}
    json.dump(doc, open(f"{out}/arms/{name}.json", "w"), indent=1)

def sgl(*flags):
    return {"sglang_image": S, "sglang_extra_flags": list(flags)}

def vl(*flags, env=None):
    return {"vllm_gpu_image": V, "vllm_extra_env": {**AITER, **(env or {})},
            "vllm_extra_flags": list(flags)}

BF16 = ["--mamba-ssm-dtype", "bfloat16"]
NOBUF = ["--mamba-radix-cache-strategy", "no_buffer"]
RATIO = ["--mamba-full-memory-ratio", "4"]
NOBUF = NOBUF + ["--disable-overlap-schedule"]   # no_buffer requires it
REPLAY = ["--enable-linear-replayssm"]
arm("h1_sglang_bf16state", "sglang_cuda", sgl(*BF16))
arm("h2_sglang_bf16_ratio4", "sglang_cuda", sgl(*BF16, *RATIO))
arm("h3_sglang_h2_replayssm", "sglang_cuda", sgl(*BF16, *RATIO, *REPLAY))
arm("h4_sglang_h3_nobuf", "sglang_cuda", sgl(*BF16, *RATIO, *REPLAY, *NOBUF))
arm("h5_sglang_h3_graphs", "sglang_cuda",
    sgl(*BF16, *RATIO, *REPLAY, "--cuda-graph-max-bs-decode", "1024"))
# vLLM accepts float32 or bfloat16 for the state (float16 is refused).
B16 = ["--mamba-ssm-cache-dtype", "bfloat16"]
arm("v1_vllm_aiter_auto", "vllm_cuda_multi", vl())
arm("v2_vllm_bf16state", "vllm_cuda_multi", vl(*B16))
arm("v3_vllm_bf16state_fa", "vllm_cuda_multi", vl(*B16, "--attention-backend", "ROCM_AITER_FA"))
arm("v4_vllm_bf16state_fa_shuffle", "vllm_cuda_multi",
    vl(*B16, "--attention-backend", "ROCM_AITER_FA",
       env={"VLLM_ROCM_SHUFFLE_KV_CACHE_LAYOUT": "1"}))

# Follow-ups: one state copy per request (no_buffer) with a smaller state share,
# since no_buffer with ratio 4 ran out of memory at 512 streams.
R2 = ["--mamba-full-memory-ratio", "2"]
arm("h6_sglang_bf16_nobuf_ratio2", "sglang_cuda", sgl(*BF16, *R2, *NOBUF))
arm("h7_sglang_h6_replayssm", "sglang_cuda", sgl(*BF16, *R2, *NOBUF, *REPLAY))
arm("h8_sglang_bf16_nobuf_replayssm", "sglang_cuda", sgl(*BF16, *NOBUF, *REPLAY))
print(sorted(os.listdir(f"{out}/arms")))
