"""Small-active MoE models on the new stack, standard shape (128 in / 256 out).

These are the models with a chance of the highest tokens per second: the
untuned baseline already had GLM-4.7-Flash and Gemma-4-26B-A4B above 15k.
m1 = vLLM, AITER on, default attention. m2 = SGLang, new image.
Hybrid (linear-attention) models get half-precision recurrent state.
"""
import json, os, sys
out = sys.argv[1]
V = "capsim/vllm-rocm:nightly-9bc16ae6-aiter-95d21128"
S = "capsim/sglang-rocm:20261115-aiter-95d21128"
AITER = {"VLLM_ROCM_USE_AITER": "1", "HSA_NO_SCRATCH_RECLAIM": "1"}
# key -> (model id, cap, hybrid)
MODELS = {
    "glm47flash": ("zai-org/GLM-4.7-Flash", 2048, False),
    "gemma26": ("RedHatAI/gemma-4-26B-A4B-it-FP8-dynamic", 2048, False),
    "qwen36a3b": ("Qwen/Qwen3.6-35B-A3B-FP8", 1024, True),
    "qwen35a3b": ("amd/Qwen3.5-35B-A3B-MXFP4", 1024, True),
    "codernext": ("amd/Qwen3-Coder-Next-MXFP4", 1024, True),
}
os.makedirs(f"{out}/arms", exist_ok=True)
for key, (model, cap, hybrid) in MODELS.items():
    for name, engine, custom in (
        ("m1_vllm", "vllm_cuda_multi",
         {"vllm_gpu_image": V, "vllm_extra_env": AITER,
          "vllm_extra_flags": ["--mamba-ssm-cache-dtype", "bfloat16"] if hybrid else []}),
        ("m2_sglang", "sglang_cuda",
         {"sglang_image": S,
          "sglang_extra_flags": ["--mamba-ssm-dtype", "bfloat16",
                                 "--mamba-full-memory-ratio", "4"] if hybrid else []}),
    ):
        doc = {"workload": {"kind": "roofline", "spec": {
                   "models": [model], "engines": [engine], "max_num_seqs": [cap],
                   "output_tokens": [256], "input_tokens": 128, "confirm_winners": False}},
               "new_run": True, "custom": {"engine": engine, **custom}}
        json.dump(doc, open(f"{out}/arms/{name}_{key}.json", "w"), indent=1)
print(sorted(os.listdir(f"{out}/arms")))
