"""Follow-ups for the two MoE models where AITER-on came in below the untuned
baseline (Gemma-4-26B-A4B FP8 14.4k vs 15.2k; GLM-4.7-Flash 12.8k vs 15.4k).
Their logs show AITER GEMM lookups missing tuned rows for 128 CUs, so:
  m0 = new image, AITER off (separates the image from AITER);
  m3 = AITER on but its linear (GEMM) path off, keeping AITER attention and MoE.
"""
import json, os, sys
out = sys.argv[1]
V = "capsim/vllm-rocm:nightly-9bc16ae6-aiter-95d21128"
MODELS = {"glm47flash": "zai-org/GLM-4.7-Flash", "gemma26": "RedHatAI/gemma-4-26B-A4B-it-FP8-dynamic"}
for key, model in MODELS.items():
    for name, env in (("m0_vllm_noaiter", {}),
                      ("m3_vllm_aiter_nolinear", {"VLLM_ROCM_USE_AITER": "1", "HSA_NO_SCRATCH_RECLAIM": "1",
                                                  "VLLM_ROCM_USE_AITER_LINEAR": "0"})):
        doc = {"workload": {"kind": "roofline", "spec": {
                   "models": [model], "engines": ["vllm_cuda_multi"], "max_num_seqs": [2048],
                   "output_tokens": [256], "input_tokens": 128, "confirm_winners": False}},
               "new_run": True,
               "custom": {"engine": "vllm_cuda_multi", "vllm_gpu_image": V, "vllm_extra_env": env}}
        json.dump(doc, open(f"{out}/arms/{name}_{key}.json", "w"), indent=1)
print(sorted(f for f in os.listdir(f"{out}/arms") if f.startswith(("m0", "m3"))))
