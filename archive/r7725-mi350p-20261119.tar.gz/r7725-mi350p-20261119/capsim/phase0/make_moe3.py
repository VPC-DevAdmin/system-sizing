"""MoE follow-ups (128 in / 256 out) on the new vLLM image with AITER on.

m1b = the two runs that lost their batch-cap and KV flags (an empty
vllm_extra_flags lever replaced the shape's flags), rerun without it.
m4  = AITER flash attention, and a 2048 cap for the hybrid models, which
were queue-bound at 1024 with the KV cache under half full.
"""
import json, os, sys
out = sys.argv[1]
V = "capsim/vllm-rocm:nightly-9bc16ae6-aiter-95d21128"
AITER = {"VLLM_ROCM_USE_AITER": "1", "HSA_NO_SCRATCH_RECLAIM": "1"}
FA = ["--attention-backend", "ROCM_AITER_FA"]
BF = ["--mamba-ssm-cache-dtype", "bfloat16"]
def arm(name, model, caps, custom):
    doc = {"workload": {"kind": "roofline", "spec": {
               "models": [model], "engines": ["vllm_cuda_multi"], "max_num_seqs": caps,
               "output_tokens": [256], "input_tokens": 128, "confirm_winners": False}},
           "new_run": True, "custom": {"engine": "vllm_cuda_multi", "vllm_gpu_image": V, **custom}}
    json.dump(doc, open(f"{out}/arms/{name}.json", "w"), indent=1)
os.makedirs(f"{out}/arms", exist_ok=True)
arm("m1b_vllm_gemma26", "RedHatAI/gemma-4-26B-A4B-it-FP8-dynamic", [2048], {"vllm_extra_env": AITER})
arm("m1b_vllm_glm47flash", "zai-org/GLM-4.7-Flash", [2048], {"vllm_extra_env": AITER})
arm("m4_vllm_fa_gemma26", "RedHatAI/gemma-4-26B-A4B-it-FP8-dynamic", [2048],
    {"vllm_extra_env": AITER, "vllm_extra_flags": FA})
for key, model in (("qwen35a3b", "amd/Qwen3.5-35B-A3B-MXFP4"),
                   ("qwen36a3b", "Qwen/Qwen3.6-35B-A3B-FP8"),
                   ("codernext", "amd/Qwen3-Coder-Next-MXFP4")):
    arm(f"m4_vllm_fa_{key}", model, [1024, 2048],
        {"vllm_extra_env": AITER, "vllm_extra_flags": BF + FA})
print(sorted(f for f in os.listdir(f"{out}/arms") if f.startswith(("m1b", "m4"))))
