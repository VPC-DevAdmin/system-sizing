"""Phase 1 arms (docs/r7725-mi350p-roofline-plan.md): one roofline cell per arm.

usage: make_phase1.py <out_dir> [vllm_image sglang_image]
Without images only the S0 reference arms (old images, defaults) are written.
"""
import json, os, sys
out = sys.argv[1]
V_IMG, S_IMG = (sys.argv[2], sys.argv[3]) if len(sys.argv) > 3 else (None, None)
# name -> (model id, engine cap). Qwen3.8-27B is a hybrid: vLLM refuses 2048
# (Mamba cache blocks), so both engines run it at 1024.
MODELS = {
    "qwen38": ("amd/Qwen3.8-27B-Quark-AWQ-MXFP4", 1024),
    # The same model in FP8: the FP8-to-MXFP4 step on AMD's showcase model.
    "qwen38f8": ("Qwen/Qwen3.8-27B-FP8", 1024),
    # Dense MXFP4 with no 128-CU tables upstream: the untuned control.
    "gemma31": ("amd/gemma-4-31B-it-MXFP4", 2048),
    # 114 GB of weights: the largest model that fits the card.
    "step35": ("amd/Step-3.5-Flash-MXFP4", 2048),
}
MXFP4_DENSE = ("qwen38", "gemma31")
AITER = {"VLLM_ROCM_USE_AITER": "1", "HSA_NO_SCRATCH_RECLAIM": "1"}
os.makedirs(f"{out}/arms", exist_ok=True)

def arm(name, engine, key, custom):
    model, cap = MODELS[key]
    doc = {"workload": {"kind": "roofline", "spec": {
               "models": [model], "engines": [engine], "max_num_seqs": [cap],
               "output_tokens": [256], "input_tokens": 128, "confirm_winners": False}},
           "new_run": True, "custom": {"engine": engine, **custom}}
    json.dump(doc, open(f"{out}/arms/{name}_{key}.json", "w"), indent=1)

def vllm_aiter(key, graphs=False, asm_fp4=False):
    env = dict(AITER)
    flags = ["--attention-backend", "ROCM_AITER_FA"]
    env["VLLM_ROCM_SHUFFLE_KV_CACHE_LAYOUT"] = "1"
    if graphs:
        flags += ["--compilation-config",
                  json.dumps({"max_cudagraph_capture_size": MODELS[key][1]})]
    if asm_fp4:
        env["VLLM_ROCM_USE_AITER_FP4_ASM_GEMM"] = "1"
    return {"vllm_gpu_image": V_IMG, "vllm_extra_env": env, "vllm_extra_flags": flags}

for key in MODELS:
    arm("s0_vllm", "vllm_cuda_multi", key, {})
    arm("s0_sglang", "sglang_cuda", key, {})
    if not V_IMG:
        continue
    arm("s2_vllm", "vllm_cuda_multi", key, vllm_aiter(key))
    arm("s3_vllm", "vllm_cuda_multi", key, vllm_aiter(key, graphs=True))
    if key in MXFP4_DENSE:
        arm("s4_vllm", "vllm_cuda_multi", key, vllm_aiter(key, graphs=True, asm_fp4=True))
    arm("s1_sglang", "sglang_cuda", key, {"sglang_image": S_IMG})
    arm("s2_sglang", "sglang_cuda", key,
        {"sglang_image": S_IMG,
         "sglang_extra_flags": ["--cuda-graph-max-bs-decode", str(MODELS[key][1])]})

# Technique arms: per-stream speed at 1..32 streams, 8k in / 1k out, on
# Qwen3.8-27B MXFP4 (vLLM), each against t0.
def tech(name, key, image, env=None, flags=None, engine="vllm_cuda_multi", extra=None):
    model, _ = MODELS[key]
    custom = {"engine": engine, "model_id": model, "tp": 1, "replicas": 1,
              "max_model_len": 10240, "gpu_memory_utilization": 0.95,
              "kv_cache_dtype": "fp8", "max_num_seqs": 64, "trust_remote_code": False}
    if engine == "sglang_cuda":
        custom["sglang_image"] = image
    else:
        e = {**AITER, "VLLM_ROCM_SHUFFLE_KV_CACHE_LAYOUT": "1", **(env or {})}
        custom.update({"vllm_gpu_image": image, "vllm_extra_env": e,
                       "vllm_extra_flags": ["--attention-backend", "ROCM_AITER_FA"] + (flags or [])})
    custom.update(extra or {})
    doc = {"custom": custom, "new_run": True,
           "workload": {"kind": "persona", "id": "headline_generation"},
           "shape": {"input_tokens": 8000, "output_tokens": 1000},
           "ladder": [1, 2, 4, 8, 16, 32]}
    json.dump(doc, open(f"{out}/arms/{name}_{key}.json", "w"), indent=1)

if V_IMG:
    spec = lambda cfg: ["--speculative-config", json.dumps(cfg)]
    tech("t0_ref", "qwen38", V_IMG)
    tech("t0_sglang", "qwen38", S_IMG, engine="sglang_cuda")
    tech("t1_mono", "qwen38", V_IMG + "-pr65078", env={"VLLM_ROCM_MONO_DECODE": "1"})
    tech("t2_fusion", "qwen38", V_IMG + "-pr61902",
         env={"VLLM_ROCM_USE_AITER_FP4_ACT_QUANT_FUSION": "1"})
    tech("t3_dflash2", "qwen38", V_IMG,
         flags=spec({"method": "dflash", "model": "amd/Qwen3.8-27B-Quark-DFlash2",
                     "num_speculative_tokens": 7}))
    tech("t4_mtp3", "qwen38", V_IMG,
         flags=spec({"method": "mtp", "num_speculative_tokens": 3}))
    tech("t5_mono_mtp3", "qwen38", V_IMG + "-pr65078",
         env={"VLLM_ROCM_MONO_DECODE": "1"},
         flags=spec({"method": "mtp", "num_speculative_tokens": 3}))
    tech("t0_ref", "gemma31", V_IMG)
    tech("t2_fusion", "gemma31", V_IMG + "-pr61902",
         env={"VLLM_ROCM_USE_AITER_FP4_ACT_QUANT_FUSION": "1"})
print(sorted(os.listdir(f"{out}/arms")))
