"""Profiling arms (p): the same cells as measured, with vLLM's torch profiler
switched on so the sidecar (prof_side.sh) can take a kernel trace. Their
tok/s is not a result: the profile perturbs the rung it lands on."""
import json, os, sys
out = sys.argv[1]
os.makedirs(f"{out}/arms", exist_ok=True)
V = "capsim/vllm-rocm:nightly-9bc16ae6-aiter-95d21128"
AITER = {"VLLM_ROCM_USE_AITER": "1", "HSA_NO_SCRATCH_RECLAIM": "1"}
SRV = ["--stream-interval", "8", "--api-server-count", "4"]
PROF = ["--profiler-config.profiler=torch",
        "--profiler-config.torch_profiler_dir=/root/.cache/huggingface/prof",
        "--profiler-config.torch_profiler_with_stack=false",
        "--profiler-config.torch_profiler_record_shapes=true"]
def arm(name, model, caps, flags, per_gpu=1):
    custom = {"engine": "vllm_cuda_multi", "vllm_gpu_image": V, "vllm_extra_env": AITER,
              "vllm_extra_flags": flags + SRV + PROF}
    if per_gpu > 1:
        custom["replicas_per_gpu"] = per_gpu
    doc = {"workload": {"kind": "roofline", "spec": {
               "models": [model], "engines": ["vllm_cuda_multi"], "max_num_seqs": caps,
               "output_tokens": [256], "input_tokens": 128, "confirm_winners": False}},
           "new_run": True, "custom": custom}
    json.dump(doc, open(f"{out}/arms/{name}.json", "w"), indent=1)
TRC = ["--trust-remote-code"]
arm("p1_lfm2_one", "LiquidAI/LFM2-24B-A2B", [4096], TRC)
arm("p2_lfm2_two", "LiquidAI/LFM2-24B-A2B", [4096], TRC, per_gpu=2)
arm("p3_gemma26", "RedHatAI/gemma-4-26B-A4B-it-FP8-dynamic", [1536], [])
arm("p4_lagunaxs", "poolside/Laguna-XS-2.1-FP8", [4096], TRC)
print(sorted(os.listdir(f"{out}/arms")))
