"""Phase 1b shape search on the MoE leaders, each on its best setting so far.

The stock ladder offers 512, 2048, 4096 streams, so the batch cap is what
sets how many run at once: sweep the cap (1024, 1536, 2048; 768 too for
Gemma, which peaked under 1024) at 256 and 1024 output tokens, 128 in.
One roofline per model; every cell is recorded.
"""
import json, os, sys
out = sys.argv[1]
V = "capsim/vllm-rocm:nightly-9bc16ae6-aiter-95d21128"
AITER = {"VLLM_ROCM_USE_AITER": "1", "HSA_NO_SCRATCH_RECLAIM": "1"}
HYB = ["--mamba-ssm-cache-dtype", "bfloat16", "--attention-backend", "ROCM_AITER_FA"]
CAPS = [1024, 1536, 2048]
MODELS = {
    "gemma26": ("RedHatAI/gemma-4-26B-A4B-it-FP8-dynamic", [768] + CAPS, {"vllm_extra_env": AITER}),
    "qwen36a3b": ("Qwen/Qwen3.6-35B-A3B-FP8", CAPS, {"vllm_extra_env": AITER, "vllm_extra_flags": HYB}),
    "glm47flash": ("zai-org/GLM-4.7-Flash", CAPS, {"vllm_extra_env": {}}),
    "qwen35a3b": ("amd/Qwen3.5-35B-A3B-MXFP4", CAPS, {"vllm_extra_env": AITER, "vllm_extra_flags": HYB}),
    "codernext": ("amd/Qwen3-Coder-Next-MXFP4", CAPS, {"vllm_extra_env": AITER, "vllm_extra_flags": HYB}),
}
os.makedirs(f"{out}/arms", exist_ok=True)
for i, (key, (model, caps, custom)) in enumerate(MODELS.items()):
    doc = {"workload": {"kind": "roofline", "spec": {
               "models": [model], "engines": ["vllm_cuda_multi"], "max_num_seqs": caps,
               "output_tokens": [256, 1024], "input_tokens": 128, "confirm_winners": False}},
           "new_run": True, "custom": {"engine": "vllm_cuda_multi", "vllm_gpu_image": V, **custom}}
    json.dump(doc, open(f"{out}/arms/s{i}_shape_{key}.json", "w"), indent=1)
print(sorted(os.listdir(f"{out}/arms")))
