"""Phase 0 smoke arms: one small roofline cell per (image, model)."""
import json, os
V_PUB = "vllm/vllm-openai-rocm:nightly-rocm100-9bc16ae6a34b1e0fe260e8d12b98568478bf38c3"
S_PUB = "rocm/sgl-dev:v0.5.23-rocm10-mi35x-20261115"
V_MAIN = "capsim/vllm-rocm:nightly-9bc16ae6-aiter-95d21128"
S_MAIN = "capsim/sglang-rocm:20261115-aiter-95d21128"
GPTOSS = "openai/gpt-oss-120b"
QWEN = "amd/Qwen3.8-27B-Quark-AWQ-MXFP4"
AITER = {"VLLM_ROCM_USE_AITER": "1", "HSA_NO_SCRATCH_RECLAIM": "1"}

def arm(name, engine, model, custom):
    doc = {"workload": {"kind": "roofline", "spec": {
               "models": [model], "engines": [engine], "max_num_seqs": [64],
               "output_tokens": [256], "input_tokens": 128, "confirm_winners": False}},
           "new_run": True, "custom": {"engine": engine, **custom}}
    os.makedirs("smoke/arms", exist_ok=True)
    json.dump(doc, open(f"smoke/arms/{name}.json", "w"), indent=1)

for tag, v, s in (("1pub", V_PUB, S_PUB), ("2main", V_MAIN, S_MAIN)):
    arm(f"{tag}_vllm_gptoss", "vllm_cuda_multi", GPTOSS,
        {"vllm_gpu_image": v, "vllm_extra_env": AITER,
         "vllm_extra_flags": ["--attention-backend", "ROCM_AITER_UNIFIED_ATTN", "--block-size", "64"]})
    arm(f"{tag}_vllm_qwen38", "vllm_cuda_multi", QWEN,
        {"vllm_gpu_image": v, "vllm_extra_env": AITER})
    arm(f"{tag}_sglang_gptoss", "sglang_cuda", GPTOSS, {"sglang_image": s})
    arm(f"{tag}_sglang_qwen38", "sglang_cuda", QWEN, {"sglang_image": s})
print(sorted(os.listdir("smoke/arms")))
