"""Technique arms: per-stream speed at 1..32 streams, 8k in / 1k out.

Base config for Qwen3.8-27B MXFP4 on vLLM is the Phase 1 winner: AITER on,
ROCM_AITER_FA attention, bfloat16 recurrent state (no shuffled KV layout:
the hybrid's KV layout rejects it). Each technique is compared with t0.
"""
import json, os, sys
out = sys.argv[1]
V = "capsim/vllm-rocm:nightly-9bc16ae6-aiter-95d21128"
S = "capsim/sglang-rocm:20261115-aiter-95d21128"
QWEN = "amd/Qwen3.8-27B-Quark-AWQ-MXFP4"
GEMMA = "amd/gemma-4-31B-it-MXFP4"
AITER = {"VLLM_ROCM_USE_AITER": "1", "HSA_NO_SCRATCH_RECLAIM": "1"}
FA = ["--attention-backend", "ROCM_AITER_FA"]
B16 = ["--mamba-ssm-cache-dtype", "bfloat16"]
os.makedirs(f"{out}/arms", exist_ok=True)

def base(model, engine, cap=64, ctx=10240):
    return {"engine": engine, "model_id": model, "tp": 1, "replicas": 1,
            "max_model_len": ctx, "gpu_memory_utilization": 0.95,
            "kv_cache_dtype": "fp8", "max_num_seqs": cap, "trust_remote_code": False}

def tech(name, model, image=V, env=None, flags=None, engine="vllm_cuda_multi"):
    custom = base(model, engine)
    if engine == "sglang_cuda":
        custom.update({"sglang_image": image, "sglang_extra_flags": flags or []})
    else:
        custom.update({"vllm_gpu_image": image, "vllm_extra_env": {**AITER, **(env or {})},
                       "vllm_extra_flags": flags or []})
    doc = {"custom": custom, "new_run": True,
           "workload": {"kind": "persona", "id": "headline_generation"},
           "shape": {"input_tokens": 8000, "output_tokens": 1000},
           "ladder": [1, 2, 4, 8, 16, 32]}
    json.dump(doc, open(f"{out}/arms/{name}.json", "w"), indent=1)

spec = lambda cfg: ["--speculative-config", json.dumps(cfg)]
MONO = {"VLLM_ROCM_MONO_DECODE": "1"}
FUSE = {"VLLM_ROCM_USE_AITER_FP4_ACT_QUANT_FUSION": "1"}
MTP3 = spec({"method": "mtp", "num_speculative_tokens": 3})
tech("t0_ref_qwen38", QWEN, flags=FA + B16)
tech("t0_sglang_qwen38", QWEN, image=S, engine="sglang_cuda",
     flags=["--mamba-ssm-dtype", "bfloat16"])
tech("t1_mono_qwen38", QWEN, image=V + "-pr65078", env=MONO, flags=FA + B16)
# In case mono decode needs the stock float32 state.
tech("t1b_mono_f32state_qwen38", QWEN, image=V + "-pr65078", env=MONO, flags=FA)
tech("t2_fusion_qwen38", QWEN, image=V + "-pr61902", env=FUSE, flags=FA + B16)
tech("t3_dflash2_qwen38", QWEN, flags=FA + B16 + spec(
    {"method": "dflash", "model": "amd/Qwen3.8-27B-Quark-DFlash2", "num_speculative_tokens": 7}))
tech("t4_mtp3_qwen38", QWEN, flags=FA + B16 + MTP3)
tech("t5_mono_mtp3_qwen38", QWEN, image=V + "-pr65078", env=MONO, flags=FA + B16 + MTP3)
# Gemma-4-31B is multimodal and rejects ROCM_AITER_FA, so it keeps the default backend.
tech("t6_ref_gemma31", GEMMA)
tech("t7_fusion_gemma31", GEMMA, image=V + "-pr61902", env=FUSE)

# Mono decode refuses a bfloat16 recurrent state, so its clean comparison is
# against references that also keep the stock float32 state.
tech("t8_ref_f32state_qwen38", QWEN, flags=FA)
tech("t9_mtp3_f32state_qwen38", QWEN, flags=FA + MTP3)
tech("t10_mono_mtp3_f32state_qwen38", QWEN, image=V + "-pr65078", env=MONO, flags=FA + MTP3)
print(sorted(os.listdir(f"{out}/arms")))
