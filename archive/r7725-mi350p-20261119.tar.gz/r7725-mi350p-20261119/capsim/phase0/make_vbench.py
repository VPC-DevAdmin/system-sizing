"""Engine-only arms for the `vllm bench serve` verification: the two-engine
LFM2 configuration held up with one capsim stream while vLLM's own tool
supplies the load (vbench.sh). The capsim figure of these arms is not a result."""
import json, sys
out = sys.argv[1]
src = json.load(open(f"{out}/arms/r1a_hold600.json"))
for name in ("v1_vbench_shared_prefix", "v2_vbench_no_prefix"):
    doc = json.loads(json.dumps(src))
    doc["ladder"], doc["hold_s"] = [1], 1800
    json.dump(doc, open(f"{out}/arms/{name}.json", "w"), indent=1)
print("v arms written")
