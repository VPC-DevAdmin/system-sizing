"""Holding arms for `vllm bench serve` on each top model: the model's best
recorded engine configuration (read from its roofline result row), kept up
by capsim with one stream for up to 30 minutes."""
import json, os, sys
out = sys.argv[1]; RES = "/data/capsim/phase1c/results"
os.makedirs(f"{out}/arms", exist_ok=True)
PLAN = [  # tag, result file, model
    ("m1_lagunaxs_sglang", "h2_sglang_stream8_lagunaxs.json", "poolside/Laguna-XS-2.1-FP8"),
    ("m2_northmini_sglang", "c6c_sglang_unified_stream8_northmini.json", "CohereLabs/North-Mini-Code-1.0-fp8"),
    ("m3_gemma26_vllm", "c6g_vllm_srv_gemma26.json", "RedHatAI/gemma-4-26B-A4B-it-FP8-dynamic"),
    ("m4_qwen35a3b_vllm", "c6i_vllm_srv_qwen35a3b.json", "amd/Qwen3.5-35B-A3B-MXFP4"),
    ("m5_puzzle75b_vllm", "i1_vllm_puzzle75b_fp8.json", "nvidia/NVIDIA-Nemotron-Labs-3-Puzzle-75B-A9B-FP8"),
    ("m6_minimax_m27_vllm", "i2_vllm_minimax_m27_mxfp4.json", "amd/MiniMax-M2.7-MXFP4"),
]
KEEP = ("engine", "tp", "replicas", "max_model_len", "gpu_memory_utilization", "kv_cache_dtype", "max_num_seqs",
        "vllm_gpu_image", "vllm_extra_env", "vllm_extra_flags", "sglang_image", "sglang_extra_flags", "sglang_extra_env")
for tag, name, model in PLAN:
    rows = [r for r in json.load(open(f"{RES}/{name}"))["results"] if r.get("model") == model and r.get("out_tok_s")]
    row = max(rows, key=lambda r: r["out_tok_s"])
    custom = {"model_id": model, **{k: row[k] for k in KEEP if k in row}}
    doc = {"workload": {"kind": "persona", "id": "headline_generation"},
           "shape": {"input_tokens": 128, "output_tokens": 256}, "ladder": [1], "hold_s": 1800,
           "new_run": True, "prefix_reuse": "industry", "custom": custom}
    json.dump(doc, open(f"{out}/arms/{tag}.json", "w"), indent=1)
    json.dump(row, open(f"{out}/arms/{tag}.source_row", "w"), indent=1)
    print(tag, row["out_tok_s"], row["max_num_seqs"], row["in_flight"], row["run_dir"])
