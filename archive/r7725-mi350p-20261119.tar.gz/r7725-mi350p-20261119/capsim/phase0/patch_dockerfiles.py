skip = '''# AITER main pins flydsl 0.5.0, but its MEGA_MOE ahead-of-time replay imports a
# symbol that release lacks. MEGA_MOE is the multi-rank expert-parallel MoE,
# unused on one GPU, so skip that replay instead of failing the build.
RUN sed -i "s/        if run_mega_moe_replay():/        if False:/" {root}/aiter/aot/flydsl/common.py \\
 && grep -n "if False:" {root}/aiter/aot/flydsl/common.py
'''
for name, root in (("Dockerfile.vllm-aiter", "/opt/aiter-src"),
                   ("Dockerfile.sglang-aiter", "/sgl-workspace/aiter")):
    s = open(name).read()
    marker = "RUN cd %s \\\n && PREBUILD" % root
    assert s.count(marker) == 1, name
    if "run_mega_moe_replay" not in s:
        s = s.replace(marker, skip.format(root=root) + marker)
    open(name, "w").write(s)
    print(name, "patched")
