#!/usr/bin/env bash
# prof_side.sh TAG THRESH : profiling sidecar for one capsim run.
# Samples the GPU once a second throughout. When the running vLLM engines
# together hold THRESH requests in flight it takes, per engine:
#   1. a py-spy profile of the engine core (12 s, Python stacks, on-CPU only)
#   2. a torch profiler trace of 30 engine steps (GPU kernels)
# Output: /data/capsim/prof/TAG and /data/capsim/huggingface/prof (traces).
TAG=$1; THRESH=$2; OUT=/data/capsim/prof/$TAG; mkdir -p $OUT
PY=/home/user/.local/share/uv/tools/py-spy/bin/py-spy
log() { echo "$(date '+%F %T') $*" >> $OUT/side.log; }
( while :; do echo "$(date +%T) $(amd-smi metric -g 0 --usage --power 2>/dev/null | grep -E 'GFX_ACTIVITY|UMC_ACTIVITY|SOCKET_POWER' | tr -s ' ' | tr '\n' ' ')"; sleep 1; done ) > $OUT/gpu_1s.log &
SMI=$!
trap 'kill $SMI 2>/dev/null' EXIT
engines() { docker ps --format '{{.Names}}' | grep '^vllm'; }
port_of() { docker inspect "$1" --format '{{join .Args " "}}' | grep -o '\-\-port [0-9]*' | cut -d' ' -f2; }
running_total() { t=0; for c in $(engines); do n=$(curl -s -m 3 localhost:$(port_of $c)/metrics | grep '^vllm:num_requests_running' | awk '{s+=$NF} END {print int(s)}'); t=$((t + ${n:-0})); done; echo $t; }
until [ "$(running_total)" -ge "$THRESH" ] || [ $SECONDS -gt 3000 ]; do sleep 2; done
log "trigger: $(running_total) in flight"
sleep 6
top -b -n 1 -w 200 -o %CPU | head -25 > $OUT/top.txt
for c in $(engines); do
  docker cp -q $PY $c:/usr/local/bin/py-spy 2>>$OUT/side.log
  ipid=$(docker exec $c sh -c 'grep -l EngineCore /proc/[0-9]*/cmdline 2>/dev/null | head -1 | cut -d/ -f3')
  log "$c engine core pid $ipid"
  docker exec --privileged $c py-spy dump --pid $ipid > $OUT/dump_$c.txt 2>&1
  docker exec --privileged $c py-spy record --pid $ipid -d 12 -r 200 -t -f raw -o /root/.cache/huggingface/prof/cpu_${TAG}_$c.txt >> $OUT/side.log 2>&1 &
done
wait $(jobs -p | grep -v "^$SMI$") 2>/dev/null
log "py-spy done: $(running_total) in flight"
for c in $(engines); do
  p=$(port_of $c)
  curl -s -m 20 -o /dev/null -w "start_profile $c %{http_code}\n" -X POST localhost:$p/start_profile -H 'Content-Type: application/json' -d "{\"profile_prefix\":\"${TAG}-${c}\",\"max_iterations\":30}" >> $OUT/side.log
done
sleep 8
for c in $(engines); do
  curl -s -m 120 -o /dev/null -w "stop_profile $c %{http_code}\n" -X POST localhost:$(port_of $c)/stop_profile >> $OUT/side.log
done
log "profile done: $(running_total) in flight"
until [ -z "$(engines)" ]; do sleep 5; done
log "engines gone"
