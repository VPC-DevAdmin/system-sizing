#!/usr/bin/env bash
# Phase 0: pull the newest published ROCm builds (network and disk only).
for img in vllm/vllm-openai-rocm:nightly-rocm100-9bc16ae6a34b1e0fe260e8d12b98568478bf38c3 rocm/sgl-dev:v0.5.23-rocm10-mi35x-20261115; do
  echo "$(date "+%F %T") pull $img"
  for try in 1 2 3; do docker pull -q "$img" && { echo "$(date "+%F %T") ok $img"; break; } || { echo "retry $try"; sleep 30; }; done
done
echo "$(date "+%F %T") pulls done"
docker images --format "{{.Repository}}:{{.Tag}} {{.ID}} {{.Size}}"
