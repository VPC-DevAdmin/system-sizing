#!/usr/bin/env python3
"""quality_probe.py TAG WAIT_IN_FLIGHT : a small scored task set against the
running vLLM engines (hardening run 4).

60 short questions with one right answer each, temperature 0, sent to every
engine container in turn. Waits until the engines together hold
WAIT_IN_FLIGHT requests (0 = as soon as they answer), so the same set can be
asked of an idle engine and of one under 8,192 streams. Writes every prompt,
reply and verdict to /data/capsim/harden/quality/TAG.json.
"""
import json, re, subprocess, sys, time, urllib.request
from concurrent.futures import ThreadPoolExecutor

TAG, WAIT = sys.argv[1], int(sys.argv[2])
OUT = f"/data/capsim/harden/quality/{TAG}.json"
SUFFIX = " Answer with only the answer, no explanation."
Q = [(f"What is {a} + {b}?", str(a + b)) for a, b in
     [(17, 26), (48, 37), (123, 456), (305, 97), (64, 64), (99, 101), (250, 175), (11, 89), (720, 280), (33, 67)]]
Q += [(f"What is {a} times {b}?", str(a * b)) for a, b in
      [(7, 8), (12, 12), (9, 13), (15, 6), (25, 4), (11, 11), (14, 3), (8, 9), (16, 5), (21, 3)]]
Q += [(f"What is the capital of {c}?", a) for c, a in
      [("France", "paris"), ("Japan", "tokyo"), ("Italy", "rome"), ("Canada", "ottawa"), ("Egypt", "cairo"),
       ("Spain", "madrid"), ("Germany", "berlin"), ("Kenya", "nairobi"), ("Peru", "lima"), ("Norway", "oslo"),
       ("Greece", "athens"), ("Ireland", "dublin"), ("Portugal", "lisbon"), ("Austria", "vienna"), ("Thailand", "bangkok")]]
Q += [("How many days are in a week?", "7"), ("How many months are in a year?", "12"),
      ("How many sides does a hexagon have?", "6"), ("How many minutes are in an hour?", "60"),
      ("What is the chemical symbol for gold?", "au"), ("What is the chemical symbol for sodium?", "na"),
      ("What planet is known as the Red Planet?", "mars"), ("What is the largest planet in the solar system?", "jupiter"),
      ("What is the freezing point of water in degrees Celsius?", "0"), ("What is the square root of 144?", "12"),
      ("What gas do plants absorb from the air?", "carbon dioxide"), ("Who wrote the play Romeo and Juliet?", "shakespeare"),
      ("What is the opposite of hot?", "cold"), ("What color do you get by mixing blue and yellow?", "green"),
      ("Which is larger, 0.7 or 0.65?", "0.7"), ("What is the next number in the sequence 2, 4, 8, 16?", "32"),
      ("What is 100 divided by 4?", "25"), ("What is 15 percent of 200?", "30"),
      ("How many letters are in the word 'banana'?", "6"), ("What is the first letter of the word 'engine'?", "e"),
      ("What is the plural of 'mouse'?", "mice"), ("What is the past tense of 'run'?", "ran"),
      ("In which continent is Brazil?", "south america"), ("What is the boiling point of water in degrees Celsius?", "100"),
      ("How many legs does a spider have?", "8")]

def engines():
    names = subprocess.run(["docker", "ps", "--format", "{{.Names}}"], capture_output=True, text=True).stdout.split()
    out = []
    for n in sorted(x for x in names if x.startswith("vllm")):
        args = subprocess.run(["docker", "inspect", n, "--format", '{{join .Args " "}}'], capture_output=True, text=True).stdout
        m = re.search(r"--port (\d+)", args)
        if m:
            out.append((n, int(m.group(1))))
    return out

def get(url, timeout=5):
    try:
        return urllib.request.urlopen(url, timeout=timeout).read().decode()
    except Exception:
        return ""

def in_flight(es):
    t = 0
    for _n, p in es:
        for line in get(f"http://127.0.0.1:{p}/metrics").splitlines():
            if line.startswith("vllm:num_requests_running"):
                t += int(float(line.split()[-1]))
    return t

deadline = time.time() + 3600
es = []
while time.time() < deadline:
    es = engines()
    if es and all('"id"' in get(f"http://127.0.0.1:{p}/v1/models") for _n, p in es) and in_flight(es) >= WAIT:
        break
    time.sleep(3)
else:
    sys.exit("engines never ready")
time.sleep(15 if WAIT else 2)
model = json.loads(get(f"http://127.0.0.1:{es[0][1]}/v1/models"))["data"][0]["id"]

def ask(i):
    q, want = Q[i]
    name, port = es[i % len(es)]
    body = json.dumps({"model": model, "temperature": 0, "max_tokens": 48,
                       "messages": [{"role": "user", "content": q + SUFFIX}]}).encode()
    req = urllib.request.Request(f"http://127.0.0.1:{port}/v1/chat/completions", body,
                                 {"Content-Type": "application/json"})
    t0 = time.time()
    try:
        r = json.loads(urllib.request.urlopen(req, timeout=300).read())
        text, err = r["choices"][0]["message"]["content"] or "", None
    except Exception as e:  # noqa: BLE001
        text, err = "", f"{type(e).__name__}: {e}"
    norm = re.sub(r"[^a-z0-9. ]", " ", text.lower())
    ok = bool(re.search(r"(?<![0-9.])" + re.escape(want) + r"(?![0-9])", norm)) if want[0].isdigit() else want in norm
    return {"i": i, "engine": name, "question": q, "expected": want, "reply": text,
            "correct": ok, "error": err, "seconds": round(time.time() - t0, 2)}

start_flight = in_flight(es)
with ThreadPoolExecutor(8) as ex:
    rows = list(ex.map(ask, range(len(Q))))
doc = {"tag": TAG, "model": model, "engines": [n for n, _ in es], "in_flight_at_start": start_flight,
       "in_flight_at_end": in_flight(es), "questions": len(Q), "correct": sum(r["correct"] for r in rows),
       "errors": sum(1 for r in rows if r["error"]), "rows": rows}
import os
os.makedirs(os.path.dirname(OUT), exist_ok=True)
json.dump(doc, open(OUT, "w"), indent=1)
print(TAG, "correct", doc["correct"], "of", len(Q), "errors", doc["errors"], "in flight", start_flight)
