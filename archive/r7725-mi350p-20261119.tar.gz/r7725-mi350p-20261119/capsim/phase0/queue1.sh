#!/usr/bin/env bash
# GPU queue: vLLM reference arms, then the rebuilt-image smoke tests once
# the builds are done, then the SGLang reference arms.
P0=/data/capsim/phase0; P1=/data/capsim/phase1
$P0/run_arms.sh $P1 s0_vllm
until grep -q "builds finished" /data/capsim/logs/phase0_build.log; do sleep 60; done
$P0/run_arms.sh $P0/smoke 2main
$P0/run_arms.sh $P1 s0_sglang
echo "$(date '+%F %T') queue1 finished"
