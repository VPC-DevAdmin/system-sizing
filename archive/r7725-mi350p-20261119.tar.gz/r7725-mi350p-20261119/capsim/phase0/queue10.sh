#!/usr/bin/env bash
P0=/data/capsim/phase0; T=/data/capsim/phase1t
until grep -q "queue9 finished" /data/capsim/logs/phase1_q9.log; do sleep 30; done
for sel in t8_ t9_ t10_; do $P0/run_arms.sh $T $sel; done
echo "$(date '+%F %T') queue10 finished"
