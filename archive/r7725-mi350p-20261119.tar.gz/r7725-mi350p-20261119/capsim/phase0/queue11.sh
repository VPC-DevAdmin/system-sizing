#!/usr/bin/env bash
P0=/data/capsim/phase0; M=/data/capsim/phase1m; C=/data/capsim/phase1c
for sel in m1b_ m4_; do $P0/run_arms.sh $M $sel; done
echo "$(date '+%F %T') moe followups finished"
$P0/run_arms.sh $C c1_
$P0/run_arms.sh $C c2_
echo "$(date '+%F %T') queue11 finished"
