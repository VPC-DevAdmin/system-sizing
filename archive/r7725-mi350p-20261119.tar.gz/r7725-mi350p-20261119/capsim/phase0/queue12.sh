#!/usr/bin/env bash
P0=/data/capsim/phase0
until grep -q "queue11 finished" /data/capsim/logs/phase1_q11.log; do sleep 60; done
$P0/run_arms.sh /data/capsim/phase1s
echo "$(date '+%F %T') queue12 finished"
