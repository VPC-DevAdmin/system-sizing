#!/usr/bin/env bash
# Takes over from queue12 (stopped between arms): keeps the Gemma shape
# result, runs the newer-model follow-ups, then the rest of the shape search.
P0=/data/capsim/phase0; C=/data/capsim/phase1c; SH=/data/capsim/phase1s
running() { curl -s -m 10 localhost:8321/api/status | grep -o '"running":[a-z]*' | cut -d: -f2; }
cd /home/user/system-sizing
until [ "$(running)" = "false" ]; do sleep 30; done
[ -f $SH/results/s0_shape_gemma26.json ] || cp runs/roofline.json $SH/results/s0_shape_gemma26.json
echo "$(date '+%F %T') gemma shape kept"
for sel in c4 c3_; do $P0/run_arms.sh $C $sel; done
echo "$(date '+%F %T') followups finished"
$P0/run_arms.sh $SH
echo "$(date '+%F %T') queue13 finished"
