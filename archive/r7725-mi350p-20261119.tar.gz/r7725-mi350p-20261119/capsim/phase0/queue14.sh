#!/usr/bin/env bash
# Takes over from queue13 during the Qwen3.6-A3B shape run: keeps its
# result, runs the serving-settings arms, then the rest of the shape search.
P0=/data/capsim/phase0; C=/data/capsim/phase1c; SH=/data/capsim/phase1s
running() { curl -s -m 10 localhost:8321/api/status | grep -o '"running":[a-z]*' | cut -d: -f2; }
cd /home/user/system-sizing
until [ "$(running)" = "false" ]; do sleep 30; done
[ -f $SH/results/s1_shape_qwen36a3b.json ] || cp runs/roofline.json $SH/results/s1_shape_qwen36a3b.json
echo "$(date '+%F %T') qwen36a3b shape kept"
$P0/run_arms.sh $C c5
echo "$(date '+%F %T') serving arms finished"
$P0/run_arms.sh $SH
echo "$(date '+%F %T') queue14 finished"
