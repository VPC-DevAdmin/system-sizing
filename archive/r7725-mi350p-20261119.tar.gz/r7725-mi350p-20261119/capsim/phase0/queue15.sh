#!/usr/bin/env bash
# Second round of serving settings (c6), then the shape search on them (x).
P0=/data/capsim/phase0; C=/data/capsim/phase1c; SH=/data/capsim/phase1s
running() { curl -s -m 10 localhost:8321/api/status | grep -o '"running":[a-z]*' | cut -d: -f2; }
$P0/run_arms.sh $C c6
echo "$(date '+%F %T') c6 arms finished"
$P0/run_arms.sh $SH x
echo "$(date '+%F %T') queue15 finished"
