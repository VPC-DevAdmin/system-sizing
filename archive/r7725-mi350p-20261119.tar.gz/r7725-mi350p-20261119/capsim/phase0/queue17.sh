#!/usr/bin/env bash
# Takes over from queue16 at the end of the arm in flight, installs the
# one-at-a-time start for shared-GPU replicas, restarts serve, reruns the
# shared-GPU arms (d), then the rest of the queue (c6, x).
P0=/data/capsim/phase0; C=/data/capsim/phase1c; SH=/data/capsim/phase1s
QPREV=/data/capsim/logs/phase1_q16.log
log() { echo "$(date '+%F %T') $*"; }
running() { curl -s -m 10 localhost:8321/api/status | grep -o '"running":[a-z]*' | cut -d: -f2; }
cd /home/user/system-sizing
pkill -f "[q]ueue16.sh"; pkill -f "[r]un_arms.sh /data/capsim/phase1"
arm=$(grep -o "start [a-z0-9_]*" $QPREV | tail -1 | cut -d" " -f2)
until [ "$(running)" != "true" ]; do sleep 30; done
if [ -n "$arm" ] && ! grep -q "done $arm" $QPREV; then
  D=$C; case $arm in x*) D=$SH;; esac
  [ -f $D/results/$arm.json ] || cp runs/roofline.json $D/results/$arm.json
  log "kept $arm"
fi
rm -rf build *.egg-info
~/.local/bin/uv tool install --force --reinstall-package capsim --with tiktoken --quiet --python 3.12 . 2>&1 | tail -2
log "capsim reinstalled"
for pid in $(pgrep -f "[b]in/capsim serve"); do kill "$pid"; done
sleep 10
setsid nohup ~/.local/bin/capsim serve > serve.log 2>&1 < /dev/null &
for i in $(seq 60); do curl -s -m 5 localhost:8321/api/status | grep -q service && break; sleep 5; done
curl -s -m 5 localhost:8321/api/status | grep -q service || { log "serve did not come back"; exit 1; }
log "serve restarted on new code"
rm -f $C/results/d1_vllm_srv_x2_lfm2.json
$P0/run_arms.sh $C d
log "shared-GPU arms finished"
$P0/run_arms.sh $C c6
$P0/run_arms.sh $SH x
log "queue17 finished"
