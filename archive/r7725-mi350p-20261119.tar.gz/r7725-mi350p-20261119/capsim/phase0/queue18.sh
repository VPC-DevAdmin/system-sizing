#!/usr/bin/env bash
# Profiling slot: after the c6 arms end, run each profiling arm with its
# sidecar (one engine, two engines, then two card-bound models).
P0=/data/capsim/phase0; PR=/data/capsim/phase1p
log() { echo "$(date '+%F %T') $*"; }
until ! pgrep -f "[r]un_arms.sh /data/capsim/phase1c" >/dev/null; do sleep 20; done
log "c6 arms ended"
mkdir -p /data/capsim/huggingface/prof /data/capsim/prof
while read arm thresh; do
  [ -f $PR/results/$arm.json ] && continue
  $P0/prof_side.sh $arm $thresh &
  side=$!
  $P0/run_arms.sh $PR $arm
  sleep 5; kill $side 2>/dev/null
  log "profiled $arm"
done <<ARMS
p1_lfm2_one 3800
p2_lfm2_two 7500
p3_gemma26 1450
p4_lagunaxs 3800
ARMS
log "queue18 finished"
