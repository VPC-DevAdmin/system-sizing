#!/usr/bin/env bash
# Arms that act on the profiles (e), then the first large-model load (g).
P0=/data/capsim/phase0; C=/data/capsim/phase1c
$P0/run_arms.sh $C e
echo "$(date '+%F %T') e arms finished"
$P0/run_arms.sh $C g
echo "$(date '+%F %T') queue19 finished"
