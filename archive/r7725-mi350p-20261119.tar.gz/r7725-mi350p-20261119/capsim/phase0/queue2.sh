#!/usr/bin/env bash
# GPU queue 2: after queue1, install the new capsim (ladder option), then
# the settings arms and the technique arms on the rebuilt images.
P0=/data/capsim/phase0; P1=/data/capsim/phase1
log() { echo "$(date '+%F %T') $*"; }
until grep -q "queue1 finished" /data/capsim/logs/phase1.log; do sleep 60; done
cd /home/user/system-sizing
rm -rf build *.egg-info
~/.local/bin/uv tool install --force --reinstall-package capsim --with tiktoken --quiet --python 3.12 . 2>&1 | tail -2
for pid in $(pgrep -f "[b]in/capsim serve"); do kill "$pid"; done
sleep 8
setsid nohup ~/.local/bin/capsim serve > serve.log 2>&1 < /dev/null &
for i in $(seq 60); do curl -s -m 5 localhost:8321/api/status | grep -q capsim && break; sleep 5; done
curl -s -m 5 localhost:8321/api/status | grep -q capsim || { log "serve did not come back"; exit 1; }
log "capsim reinstalled, serve restarted"
for sel in s1_sglang_qwen38 s2_vllm_qwen38 s3_vllm_qwen38 s2_sglang_qwen38 s4_vllm_qwen38 \
           t0_ t1_ t2_ t3_ t4_ t5_ s0_ s1_ s2_ s3_ s4_; do
  $P0/run_arms.sh $P1 $sel
done
log "queue2 finished"
