#!/usr/bin/env bash
# Next iteration (h), then first loads of the larger models (i).
P0=/data/capsim/phase0; C=/data/capsim/phase1c
$P0/run_arms.sh $C h
echo "$(date '+%F %T') h arms finished"
$P0/run_arms.sh $C i
echo "$(date '+%F %T') queue20 finished"
