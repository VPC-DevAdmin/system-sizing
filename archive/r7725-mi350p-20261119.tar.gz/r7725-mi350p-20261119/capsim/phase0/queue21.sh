#!/usr/bin/env bash
# k arms, then the LFM2 kernel tuning (needs the GPU to itself).
P0=/data/capsim/phase0; C=/data/capsim/phase1c
$P0/run_arms.sh $C k
echo "$(date '+%F %T') k arms finished"
$P0/tune_lfm2.sh
echo "$(date '+%F %T') tuning container started"
