#!/usr/bin/env bash
# Hardening runs. Waits for the kernel tuning to release the GPU (up to 25
# minutes, then stops it: the expert kernels showed no gain at the batch
# sizes that matter and the dense tuning is 34,688 trials).
P0=/data/capsim/phase0; H=/data/capsim/harden
log() { echo "$(date '+%F %T') $*"; }
for i in $(seq 50); do
  docker ps --format '{{.Names}}' | grep -q '^aiter-tune-lfm2$' || break
  sleep 30
done
if docker ps --format '{{.Names}}' | grep -q '^aiter-tune-lfm2$'; then
  docker stop -t 20 aiter-tune-lfm2 >/dev/null; log "tuning stopped unfinished"
else
  log "tuning container ended"
fi
for arm in r1a_hold600 r1b_hold600 r1c_hold600 r2_batch50k r3_hold600_reuse_off; do
  $P0/run_arms.sh $H $arm
done
log "headline hardening arms finished"
while read arm wait; do
  [ -f $H/results/$arm.json ] && continue
  python3 $P0/quality_probe.py $arm $wait >> $H/quality.log 2>&1 &
  $P0/run_arms.sh $H $arm
  wait
done <<ARMS
r4a_quality_bf16kv_idle 0
r4b_quality_fp8kv_idle 0
r4c_quality_fp8kv_loaded 7500
ARMS
$P0/run_arms.sh $H r5_hold600_1k1k
log "queue22 finished"
