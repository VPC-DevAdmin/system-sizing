#!/usr/bin/env bash
# After the hardening runs: `vllm bench serve` against both engines, with the
# shared 71-token prefix capsim used (v1) and with no shared prefix (v2).
P0=/data/capsim/phase0; H=/data/capsim/harden
log() { echo "$(date '+%F %T') $*"; }
until grep -q "queue22 finished" /data/capsim/logs/phase1_q22.log; do sleep 30; done
while read arm pre inp; do
  [ -f $H/vbench/$arm/done ] && continue
  $P0/vbench.sh $arm $pre $inp 50000 < /dev/null &
  $P0/run_arms.sh $H $arm < /dev/null
  wait
  log "vbench $arm finished"
done <<ARMS
v1_vbench_shared_prefix 71 57
v2_vbench_no_prefix 0 128
ARMS
log "queue23 finished"
