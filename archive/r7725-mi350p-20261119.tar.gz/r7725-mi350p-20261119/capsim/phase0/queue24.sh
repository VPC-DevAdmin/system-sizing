#!/usr/bin/env bash
# After the benchmark-tool verification: the 1,024 in / 1,024 out hold again
# at a stream count under the engines' memory limit (r5 was over-driven:
# 8,192 offered, about 4,080 admitted, the rest timed out waiting).
P0=/data/capsim/phase0; H=/data/capsim/harden
log() { echo "$(date '+%F %T') $*"; }
until grep -q "queue23 finished" /data/capsim/logs/phase1_q23.log; do sleep 30; done
$P0/run_arms.sh $H r5b_hold600_1k1k_3840 < /dev/null
log "queue24 finished"
