#!/usr/bin/env bash
# `vllm bench serve` verification again with the open-file limit raised
# (queue23's two runs lost 96% of their requests to it), plus one run at
# 2,048 streams per engine, then the 1,024 in / 1,024 out hold under the
# engines' memory limit.
P0=/data/capsim/phase0; H=/data/capsim/harden
log() { echo "$(date '+%F %T') $*"; }
until grep -q "queue23 finished" /data/capsim/logs/phase1_q23.log; do sleep 30; done
sleep 20
while read arm pre inp n conc; do
  [ -f $H/vbench/$arm/done ] && continue
  $P0/vbench.sh $arm $pre $inp $n $conc < /dev/null &
  $P0/run_arms.sh $H $arm < /dev/null
  wait
  log "vbench $arm finished"
done <<ARMS
v1b_vbench_shared_prefix 71 57 50000 4096
v2b_vbench_no_prefix 0 128 50000 4096
v3_vbench_shared_prefix_2048 71 57 30000 2048
ARMS
$P0/run_arms.sh $H r5b_hold600_1k1k_3840 < /dev/null
log "queue25 finished"
