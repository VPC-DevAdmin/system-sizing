#!/usr/bin/env bash
# After the AIPerf campaign: the two remaining `vllm bench serve` runs
# (fully unique prompts at 4,096 streams per engine; shared prefix at 2,048
# per engine), then the 1,024 in / 1,024 out hold under the memory limit.
P0=/data/capsim/phase0; H=/data/capsim/harden
log() { echo "$(date '+%F %T') $*"; }
sleep 60
until ! curl -s -m 5 localhost:8321/api/status | grep -q '"running":true'; do sleep 30; done
touch $H/aiperf/stop
log "campaign ended, sampler stopped"
sleep 20
while read arm pre inp n conc; do
  [ -f $H/vbench/$arm/done ] && continue
  $P0/vbench.sh $arm $pre $inp $n $conc < /dev/null &
  $P0/run_arms.sh $H $arm < /dev/null
  wait
  log "vbench $arm finished"
done <<ARMS
v2b_vbench_no_prefix 0 128 50000 4096
v3_vbench_shared_prefix_2048 71 57 30000 2048
ARMS
$P0/run_arms.sh $H r5b_hold600_1k1k_3840 < /dev/null
log "queue26 finished"
