#!/usr/bin/env bash
# `vllm bench serve` on the best recorded configuration of each top model:
# 71-token shared prefix + 57 unique tokens in, 256 out, streams at the
# engine's cap, sized for about 8 minutes of load.
P0=/data/capsim/phase0; H=/data/capsim/vbench_models
log() { echo "$(date '+%F %T') $*"; }
until ! curl -s -m 5 localhost:8321/api/status | grep -q '"running":true'; do sleep 15; done
while read arm n conc; do
  [ -f $H/vbench/$arm/done ] && continue
  $P0/vbench2.sh $H $arm 71 57 $n $conc 1 < /dev/null &
  $P0/run_arms.sh $H $arm < /dev/null
  wait
  log "vbench $arm finished"
done <<ARMS
m3_gemma26_vllm 32000 1536
m4_qwen35a3b_vllm 30000 2048
m1_lagunaxs_sglang 50000 4096
m2_northmini_sglang 47000 2048
m6_minimax_m27_vllm 12500 512
m5_puzzle75b_vllm 7000 1024
ARMS
log "queue27 finished"
