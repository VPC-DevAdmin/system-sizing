#!/usr/bin/env bash
# Rest of the per-model `vllm bench serve` runs, with the shared-prefix /
# unique split capsim used for each model (it differs by engine and chat
# template: Laguna-XS 64 + 64, North-Mini 15 + 113, the others 71 + 57).
P0=/data/capsim/phase0; H=/data/capsim/vbench_models
log() { echo "$(date '+%F %T') $*"; }
until [ -f $H/vbench/m4_qwen35a3b_vllm/done ] || grep -q "never ready" $H/vbench/m4_qwen35a3b_vllm/vbench.log 2>/dev/null; do sleep 15; done
sleep 30
until ! curl -s -m 5 localhost:8321/api/status | grep -q '"running":true'; do sleep 15; done
while read arm pre inp n conc; do
  [ -f $H/vbench/$arm/done ] && continue
  $P0/vbench2.sh $H $arm $pre $inp $n $conc 1 < /dev/null &
  $P0/run_arms.sh $H $arm < /dev/null
  wait
  log "vbench $arm finished"
done <<ARMS
m1_lagunaxs_sglang 64 64 50000 4096
m2_northmini_sglang 15 113 47000 2048
m6_minimax_m27_vllm 71 57 12500 512
m5_puzzle75b_vllm 71 57 7000 1024
ARMS
log "queue27 finished"
