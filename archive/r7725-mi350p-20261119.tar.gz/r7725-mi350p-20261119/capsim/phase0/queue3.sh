#!/usr/bin/env bash
P0=/data/capsim/phase0; H=/data/capsim/phase1h
for sel in h1_ h2_ h3_ h4_ h5_ v1_ v2_ v3_ v4_; do $P0/run_arms.sh $H $sel; done
echo "$(date '+%F %T') queue3 finished"
