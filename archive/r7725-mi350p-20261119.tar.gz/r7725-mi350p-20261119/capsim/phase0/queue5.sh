#!/usr/bin/env bash
P0=/data/capsim/phase0; H=/data/capsim/phase1h
until grep -q "queue3 finished" /data/capsim/logs/phase1_q4.log; do sleep 30; done
for sel in h6_ h7_ h8_; do $P0/run_arms.sh $H $sel; done
echo "$(date '+%F %T') queue5 finished"
