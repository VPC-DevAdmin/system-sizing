#!/usr/bin/env bash
P0=/data/capsim/phase0; M=/data/capsim/phase1m
until grep -q "queue5 finished" /data/capsim/logs/phase1_q5.log; do sleep 30; done
$P0/run_arms.sh $M m1_vllm
echo "$(date '+%F %T') queue6 finished"
