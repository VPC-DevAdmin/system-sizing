#!/usr/bin/env bash
P0=/data/capsim/phase0
until grep -q "queue6 finished" /data/capsim/logs/phase1_q6.log; do sleep 30; done
$P0/run_arms.sh /data/capsim/phase1t t
echo "$(date '+%F %T') technique arms finished"
$P0/run_arms.sh /data/capsim/phase1m m2_sglang
echo "$(date '+%F %T') queue7 finished"
