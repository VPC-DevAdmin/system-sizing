#!/usr/bin/env bash
P0=/data/capsim/phase0
until grep -q "queue7 finished" /data/capsim/logs/phase1_q7.log; do sleep 30; done
$P0/run_arms.sh /data/capsim/phase1m m0_
$P0/run_arms.sh /data/capsim/phase1m m3_
echo "$(date '+%F %T') queue8 finished"
