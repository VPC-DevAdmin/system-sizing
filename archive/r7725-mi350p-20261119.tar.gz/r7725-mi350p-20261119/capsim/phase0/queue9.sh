#!/usr/bin/env bash
# After the technique arms in flight finish: retry mono decode on the rebuilt
# image, then the MoE models on SGLang and the AITER follow-ups.
P0=/data/capsim/phase0; T=/data/capsim/phase1t; M=/data/capsim/phase1m
while pgrep -f "[r]un_arms.sh" >/dev/null; do sleep 30; done
mkdir -p $T/try1
for a in t1_mono_qwen38 t1b_mono_f32state_qwen38 t5_mono_mtp3_qwen38; do
  if grep -q '"error"' $T/results/$a.json 2>/dev/null; then mv $T/results/$a.json $T/try1/; fi
done
$P0/run_arms.sh $T t1
$P0/run_arms.sh $T t5
echo "$(date '+%F %T') technique arms finished"
$P0/run_arms.sh $M m2_sglang
$P0/run_arms.sh $M m0_
$P0/run_arms.sh $M m3_
echo "$(date '+%F %T') queue9 finished"
