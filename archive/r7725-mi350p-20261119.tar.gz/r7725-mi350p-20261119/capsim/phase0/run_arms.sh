#!/usr/bin/env bash
# Run every arm JSON in <dir>/arms as its own roofline, one after another,
# and keep each run's state in <dir>/results. Arms already done are skipped;
# an optional second argument is a filename prefix to select arms.
cd /home/user/system-sizing
D=$1; SEL=${2:-}
mkdir -p "$D/results"
log() { echo "$(date '+%F %T') $*"; }
running() { curl -s -m 10 localhost:8321/api/status | grep -o '"running":[a-z]*' | cut -d: -f2; }
for f in "$D"/arms/${SEL}*.json; do
  arm=$(basename "$f" .json)
  [ -f "$D/results/$arm.json" ] && { log "skip $arm (done)"; continue; }
  if [ "$(running)" = "true" ]; then log "a run is active; stopping"; exit 1; fi
  log "start $arm"
  curl -s -m 120 -X POST localhost:8321/api/runs -H 'Content-Type: application/json' -d @"$f" | head -c 300; echo
  for i in $(seq 30); do [ "$(running)" = "true" ] && break; sleep 10; done
  if [ "$(running)" != "true" ]; then log "$arm did not start"; continue; fi
  until [ "$(running)" = "false" ]; do sleep 30; done
  if grep -q '"kind": "roofline"' "$f"; then
    cp runs/roofline.json "$D/results/$arm.json"
  else
    # A persona sweep: its result is the newest run directory's sweep file.
    rd=$(ls -td runs/run_* | head -1)
    if [ -f "$rd/headline_sweep.json" ]; then cp "$rd/headline_sweep.json" "$D/results/$arm.json"
    else echo "{\"error\": \"no headline_sweep.json in $rd\", \"run_dir\": \"$rd\"}" > "$D/results/$arm.json"; fi
  fi
  log "done $arm"
done
log "all arms done"
