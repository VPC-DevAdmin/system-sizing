#!/usr/bin/env bash
# sample_counters.sh OUT : every 2 s, each vLLM engine's generated-token,
# prompt-token and prefix-cache counters; every 30 s the busiest processes.
# Runs until OUT/stop exists. Used beside third-party load tools so their
# figures can be set against the engines' own counts.
OUT=$1; mkdir -p $OUT; rm -f $OUT/stop
port_of() { docker inspect "$1" --format '{{join .Args " "}}' | grep -o '\-\-port [0-9]*' | cut -d' ' -f2; }
n=0
while [ ! -f $OUT/stop ]; do
  line="$(date +%s.%N)"
  for c in $(docker ps --format '{{.Names}}' | grep '^vllm' | sort); do
    line="$line $c $(curl -s -m 5 localhost:$(port_of $c)/metrics | awk '/^vllm:(generation_tokens_total|prompt_tokens_total|prefix_cache_queries_total|prefix_cache_hits_total)/ {split($1,a,"{"); printf "%s=%s ", a[1], $NF}')"
  done
  echo "$line" >> $OUT/counters.log
  if [ $((n % 15)) -eq 0 ]; then { date +%T; top -b -n 1 -w 200 -o %CPU | sed -n 8,22p; } >> $OUT/top.log; fi
  n=$((n + 1)); sleep 2
done
