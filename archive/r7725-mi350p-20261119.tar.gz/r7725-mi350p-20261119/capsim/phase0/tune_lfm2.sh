#!/usr/bin/env bash
# Runs the m arms (MiniMax-M2.7 at 1k/1k), then the LFM2 kernel tuning.
/data/capsim/phase0/run_arms.sh /data/capsim/phase1c m
echo "$(date '+%F %T') m arms finished"
/data/capsim/phase0/tune_lfm2_real.sh
