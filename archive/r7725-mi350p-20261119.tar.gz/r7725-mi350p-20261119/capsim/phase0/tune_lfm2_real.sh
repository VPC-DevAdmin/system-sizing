#!/usr/bin/env bash
# Tune AITER's expert and dense kernels for LFM2-24B-A2B's shapes on this
# card (128 CUs). Runs in a named container that is kept, so the tuned
# tables and rebuilt kernels can be saved as an image with docker commit.
# Needs the GPU to itself. Output and logs: /data/capsim/aiter-tuned/lfm2
T=/data/capsim/aiter-tuned/lfm2; mkdir -p $T
IMG=capsim/vllm-rocm:nightly-9bc16ae6-aiter-95d21128
python3 - "$T" <<'PY'
import sys
t = sys.argv[1]
toks = [512, 1024, 2048, 4096, 8192]
with open(f"{t}/fmoe_untuned.csv", "w") as f:
    f.write("token,model_dim,inter_dim,expert,topk,act_type,dtype,q_dtype_a,q_dtype_w,q_type,use_g1u1,doweight_stage1\n")
    for m in toks:
        f.write(f"{m},2048,1536,64,4,ActivationType.Silu,torch.bfloat16,torch.bfloat16,torch.bfloat16,QuantType.No,1,0\n")
with open(f"{t}/bf16_untuned.csv", "w") as f:
    f.write("M,N,K,bias,dtype,outdtype,scaleAB,bpreshuffle\n")
    for n, k in [(2048, 2048), (6144, 2048), (3072, 2048), (23552, 2048), (2048, 11776), (64, 2048), (65536, 2048)]:
        for m in toks:
            f.write(f"{m},{n},{k},False,torch.bfloat16,torch.bfloat16,False,False\n")
PY
G=""; for g in $(stat -c %g /dev/kfd /dev/dri/renderD* | sort -u); do G="$G --group-add $g"; done
docker rm -f aiter-tune-lfm2 >/dev/null 2>&1
rm -f $T/status
docker run -d --name aiter-tune-lfm2 --device=/dev/kfd --device=/dev/dri $G \
  --security-opt seccomp=unconfined --ipc=host -v $T:/tuned --entrypoint bash $IMG -c '
cd /opt/aiter-src
python3 csrc/ck_gemm_moe_2stages_codegen/gemm_moe_tune.py -i /tuned/fmoe_untuned.csv --compare --update_improved --min_improvement_pct 5 > /tuned/fmoe.log 2>&1
echo "$(date +%T) fmoe rc $?" >> /tuned/status
python3 csrc/gemm_a16w16/gemm_a16w16_tune.py --input_file /tuned/bf16_untuned.csv --compare --update_improved --min_improvement_pct 5 > /tuned/bf16.log 2>&1
echo "$(date +%T) bf16 rc $?" >> /tuned/status
python3 -c "
from aiter.jit.core import AITER_CONFIG_FMOE, AITER_CONFIG_GEMM_BF16
import shutil
for p in (AITER_CONFIG_FMOE, AITER_CONFIG_GEMM_BF16):
    for q in str(p).split(\":\"):
        shutil.copy(q, \"/tuned/\")
        print(q)
" >> /tuned/status 2>&1
echo "$(date +%T) tuning finished" >> /tuned/status'
