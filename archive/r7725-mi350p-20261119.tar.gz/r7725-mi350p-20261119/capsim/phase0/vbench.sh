#!/usr/bin/env bash
# vbench.sh TAG PREFIX_LEN INPUT_LEN NUM_PROMPTS [STREAMS_PER_ENGINE]
# Verification with vLLM's own load tool: one `vllm bench serve` client per
# engine, run inside that engine's container, both at once, 4,096 streams
# each. Random-token prompts: PREFIX_LEN tokens shared by every request plus
# INPUT_LEN unique ones; 256 output tokens, end-of-sequence ignored.
# Reads each engine's counters before and after, so the clients' token
# totals can be set against the engines'. Output: /data/capsim/harden/vbench/TAG
TAG=$1; PRE=$2; INP=$3; N=$4; CONC=${5:-4096}
OUT=/data/capsim/harden/vbench/$TAG; RES=/data/capsim/huggingface/bench/$TAG
mkdir -p $OUT; rm -f $OUT/done
log() { echo "$(date '+%F %T') $*" >> $OUT/vbench.log; }
engines() { docker ps --format '{{.Names}}' | grep '^vllm' | sort; }
port_of() { docker inspect "$1" --format '{{join .Args " "}}' | grep -o '\-\-port [0-9]*' | cut -d' ' -f2; }
ready() { [ "$(engines | wc -l)" -ge 2 ] || return 1; for c in $(engines); do curl -sf -m 3 localhost:$(port_of $c)/v1/models >/dev/null || return 1; done; }
snap() { for c in $(engines); do echo "$c $(date +%s.%N) $(curl -s -m 15 localhost:$(port_of $c)/metrics | awk '/^vllm:(generation_tokens_total|prompt_tokens_total|prefix_cache_queries_total|prefix_cache_hits_total)/ {printf "%s=%s ", $1, $NF}')"; done; }
for i in $(seq 400); do ready && break; sleep 5; done
ready || { log "engines never ready"; exit 1; }
sleep 25
log "engines ready: $(engines | tr '\n' ' ')"
snap > $OUT/counters_start.txt
pids=""; i=0
for c in $(engines); do
  # The container's soft open-file limit is 1,024; one socket per stream
  # needs more (the first attempt lost 47,963 of 50,000 requests to it).
  docker exec -e HF_HUB_OFFLINE=1 $c sh -c "ulimit -n 65536; exec vllm bench serve --backend openai-chat \
    --endpoint /v1/chat/completions --host 127.0.0.1 --port $(port_of $c) \
    --dataset-name random --random-prefix-len $PRE --random-input-len $INP \
    --random-output-len 256 --ignore-eos --temperature 0.7 --num-prompts $N \
    --max-concurrency $CONC --request-rate inf --seed $((11 + i)) --disable-tqdm \
    --save-result --result-dir /root/.cache/huggingface/bench/$TAG \
    --result-filename engine$i.json" > $OUT/engine$i.log 2>&1 &
  pids="$pids $!"; i=$((i + 1))
done
# Engine generated-token counters every 2 s, so the rate inside the run
# comes from the engines and not from the clients.
( while :; do
    line="$(date +%s.%N)"
    for c in $(engines); do line="$line $(curl -s -m 5 localhost:$(port_of $c)/metrics | awk '/^vllm:generation_tokens_total/ {print $NF}')"; done
    echo "$line"; sleep 2
  done ) > $OUT/gen_counters.log 2>&1 &
SAMP=$!
( while :; do date +%T; top -b -n 1 -w 200 -o %CPU | sed -n 8,15p; sleep 30; done ) > $OUT/top.log 2>&1 &
TOP=$!
wait $pids
kill $TOP $SAMP 2>/dev/null
snap > $OUT/counters_end.txt
cp $RES/*.json $OUT/ 2>/dev/null
log "clients finished"
curl -s -m 60 -X POST localhost:8321/api/runs/stop >> $OUT/vbench.log 2>&1
touch $OUT/done
