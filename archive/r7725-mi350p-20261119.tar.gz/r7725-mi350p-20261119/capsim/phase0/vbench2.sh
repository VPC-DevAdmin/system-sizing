#!/usr/bin/env bash
# vbench2.sh ROOT TAG PREFIX_LEN INPUT_LEN NUM_PROMPTS STREAMS NUM_ENGINES
# `vllm bench serve` against whatever engine capsim is holding up (vLLM or
# SGLang), one client per engine. Random-token prompts: PREFIX_LEN tokens
# shared by every request plus INPUT_LEN unique ones; 256 output tokens,
# end-of-sequence ignored. For a vLLM engine the client runs inside the
# engine's container; for SGLang it runs in a second container from the vLLM
# image with the engine's mounts. Engine token counters are sampled every
# 2 s. Output: ROOT/vbench/TAG. Stops the capsim holding run at the end.
ROOT=$1; TAG=$2; PRE=$3; INP=$4; N=$5; CONC=$6; NENG=${7:-1}
VIMG=capsim/vllm-rocm:nightly-9bc16ae6-aiter-95d21128
OUT=$ROOT/vbench/$TAG; mkdir -p $OUT; rm -f $OUT/done
log() { echo "$(date '+%F %T') $*" >> $OUT/vbench.log; }
engines() { docker ps --format '{{.Names}}' | grep -E '^(vllm|sglang)' | grep -v '^vbench' | sort; }
port_of() { docker inspect "$1" --format '{{join .Args " "}}' | grep -o '\-\-port [0-9]*' | cut -d' ' -f2; }
ready() { [ "$(engines | wc -l)" -ge $NENG ] || return 1; for c in $(engines); do curl -sf -m 3 localhost:$(port_of $c)/v1/models >/dev/null || return 1; done; }
metrics() { curl -s -m 15 localhost:$(port_of $1)/metrics | awk '/^(vllm|sglang):(generation_tokens_total|prompt_tokens_total|prefix_cache_queries_total|prefix_cache_hits_total|cached_tokens_total)/ {split($1,a,"{"); s[a[1]]+=$NF} END {for (k in s) printf "%s=%s ", k, s[k]}'; }
snap() { for c in $(engines); do echo "$c $(date +%s.%N) $(metrics $c)"; done; }
for i in $(seq 480); do ready && break; sleep 5; done
ready || { log "engines never ready"; curl -s -m 60 -X POST localhost:8321/api/runs/stop >> $OUT/vbench.log 2>&1; exit 1; }
sleep 25
log "engines ready: $(engines | tr '\n' ' ')"
snap > $OUT/counters_start.txt
BENCH="vllm bench serve --backend openai-chat --endpoint /v1/chat/completions --host 127.0.0.1 \
  --dataset-name random --random-prefix-len $PRE --random-input-len $INP --random-output-len 256 \
  --ignore-eos --temperature 0.7 --num-prompts $N --max-concurrency $CONC --request-rate inf \
  --trust-remote-code --disable-tqdm --save-result --result-dir /root/.cache/huggingface/bench/$TAG"
pids=""; i=0
for c in $(engines); do
  ARGS="$BENCH --port $(port_of $c) --seed $((11 + i)) --result-filename engine$i.json"
  case $c in
    vllm*) docker exec -e HF_HUB_OFFLINE=1 $c sh -c "ulimit -n 65536; exec $ARGS" > $OUT/engine$i.log 2>&1 & ;;
    *) docker run --rm --name vbench-client-$i --network host --ulimit nofile=65536:65536 -e HF_HUB_OFFLINE=1 \
         $(docker inspect $c --format '{{range .Mounts}}-v {{.Source}}:{{.Destination}} {{end}}') \
         --entrypoint sh $VIMG -c "exec $ARGS" > $OUT/engine$i.log 2>&1 & ;;
  esac
  pids="$pids $!"; i=$((i + 1))
done
( while :; do
    line="$(date +%s.%N)"
    for c in $(engines); do line="$line $(curl -s -m 5 localhost:$(port_of $c)/metrics | awk '/^(vllm|sglang):generation_tokens_total/ {s+=$NF} END {print s+0}')"; done
    echo "$line"; sleep 2
  done ) > $OUT/gen_counters.log 2>&1 &
SAMP=$!
( while :; do date +%T; top -b -n 1 -w 200 -o %CPU | sed -n 8,15p; sleep 30; done ) > $OUT/top.log 2>&1 &
TOP=$!
wait $pids
kill $TOP $SAMP 2>/dev/null
snap > $OUT/counters_end.txt
cp /data/capsim/huggingface/bench/$TAG/*.json $OUT/ 2>/dev/null
log "clients finished"
curl -s -m 60 -X POST localhost:8321/api/runs/stop >> $OUT/vbench.log 2>&1
touch $OUT/done
