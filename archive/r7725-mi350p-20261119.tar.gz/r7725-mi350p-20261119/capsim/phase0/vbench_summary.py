#!/usr/bin/env python3
"""vbench_summary.py ROOT [TAG...] : one block per `vllm bench serve` run:
the tool's own totals, the engine counter rate over the steady part of the
load (first 30 s and last 60 s left out), and the capsim row it was held
against."""
import glob, json, os, re, sys
root = sys.argv[1]
tags = sys.argv[2:] or sorted(os.path.basename(p) for p in glob.glob(root + "/vbench/*") if os.path.exists(p + "/done"))
for tag in tags:
    d = f"{root}/vbench/{tag}"
    print("==", tag, "|", open(d + "/vbench.log").read().replace("\n", " | ")[:160])
    src = f"{root}/arms/{tag}.source_row"
    if os.path.exists(src):
        r = json.load(open(src)); print("  capsim row:", r["out_tok_s"], "in flight", r["in_flight"], "cap", r["max_num_seqs"], r["run_dir"])
    tot = 0.0
    for f in sorted(glob.glob(d + "/engine*.json")):
        j = json.load(open(f)); tot += j["output_throughput"]
        print("  tool:", {k: (round(j[k], 1) if isinstance(j[k], float) else j[k]) for k in
              ("duration", "completed", "failed", "total_input_tokens", "total_output_tokens", "output_throughput",
               "max_concurrent_requests", "median_ttft_ms", "p99_ttft_ms", "median_tpot_ms", "p99_tpot_ms")})
    if not glob.glob(d + "/engine*.json"):
        for f in sorted(glob.glob(d + "/engine*.log")):
            print("  no result file;", f, ":", " / ".join(open(f).read().strip().splitlines()[-4:])[:500])
        continue
    rows = []
    for l in open(d + "/gen_counters.log"):
        p = l.split()
        try: rows.append((float(p[0]), sum(float(x) for x in p[1:])))
        except (ValueError, IndexError): pass
    med = sorted(b[1] - a[1] for a, b in zip(rows, rows[1:]))[len(rows) // 2] if len(rows) > 2 else 0
    act = [i for i in range(1, len(rows)) if rows[i][1] - rows[i - 1][1] > max(200, med * 0.2)]
    if act:
        i0, i1 = act[0] - 1, act[-1]
        a = [r for r in rows if rows[i0][0] + 30 <= r[0] <= rows[i1][0] - 60]
        print("  tool tok/s (whole batch):", round(tot), "| engine active span", round(rows[i1][0] - rows[i0][0], 1), "s rate",
              round((rows[i1][1] - rows[i0][1]) / (rows[i1][0] - rows[i0][0])),
              "| steady", round(a[-1][0] - a[0][0], 1), "s rate", round((a[-1][1] - a[0][1]) / (a[-1][0] - a[0][0])) if len(a) > 1 else None)
        w = [round((a[i + 15][1] - a[i][1]) / (a[i + 15][0] - a[i][0])) for i in range(0, len(a) - 15, 15)]
        print("  30 s windows:", w)
    def tot_of(f):
        out = {}
        for k, v in re.findall(r"((?:vllm|sglang):\w+)=([0-9.e+]+)", open(d + "/" + f).read()):
            out[k.split(":")[1]] = out.get(k.split(":")[1], 0) + float(v)
        return out
    s, e = tot_of("counters_start.txt"), tot_of("counters_end.txt")
    g = {k: e[k] - s.get(k, 0) for k in e}
    hit = g.get("prefix_cache_hits_total", g.get("cached_tokens_total"))
    den = g.get("prefix_cache_queries_total", g.get("prompt_tokens_total"))
    print("  engine totals:", {k: round(v) for k, v in g.items()}, "| cache hit rate", round(hit / den, 3) if hit is not None and den else None)
