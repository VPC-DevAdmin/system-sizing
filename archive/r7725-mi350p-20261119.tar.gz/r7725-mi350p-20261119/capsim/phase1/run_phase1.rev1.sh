#!/usr/bin/env bash
# Phase 1 knob A/B on the R7725 (docs/r7725-mi350p-roofline-plan.md).
# 1. wait for the running roofline to end
# 2. archive its state (a fresh roofline overwrites runs/roofline.json)
# 3. restart capsim serve on the newly installed code
# 4. run each arm as a one-cell roofline, archiving its state after
cd /home/user/system-sizing
P=/data/capsim/phase1
log() { echo "$(date '+%F %T') $*"; }
running() { curl -s -m 10 localhost:8321/api/status | grep -o '"running":[a-z]*' | cut -d: -f2; }

until [ "$(running)" = "false" ]; do sleep 120; done
log "baseline roofline ended"
cp -n runs/roofline.json runs/roofline-fp8-bf16-2026-11-15.json
cmp -s runs/roofline.json runs/roofline-fp8-bf16-2026-11-15.json \
  || { log "ARCHIVE MISMATCH, stopping"; exit 1; }
log "archived baseline state"

# Restart serve on the installed code (installed by the deploy step below).
if [ -f "$P/REINSTALL" ]; then
  rm -rf build *.egg-info
  ~/.local/bin/uv tool install --force --reinstall-package capsim --with tiktoken --quiet --python 3.12 . 2>&1 | tail -2
  rm -f "$P/REINSTALL"; log "capsim reinstalled"
fi
for pid in $(pgrep -f "bin/capsim serve"); do kill "$pid"; done
sleep 10
setsid nohup ~/.local/bin/capsim serve > serve.log 2>&1 < /dev/null &
for i in $(seq 60); do [ -n "$(running)" ] && break; sleep 5; done
[ -n "$(running)" ] || { log "serve did not come back"; exit 1; }
log "serve restarted"

for f in "$P"/arms/*.json; do
  arm=$(basename "$f" .json)
  [ -f "$P/results/$arm.json" ] && { log "skip $arm (done)"; continue; }
  log "start $arm"
  resp=$(curl -s -m 120 -X POST localhost:8321/api/runs -H 'Content-Type: application/json' -d @"$f")
  echo "$resp" | head -c 400; echo
  for i in $(seq 30); do [ "$(running)" = "true" ] && break; sleep 10; done
  if [ "$(running)" != "true" ]; then log "$arm did not start"; continue; fi
  until [ "$(running)" = "false" ]; do sleep 60; done
  cp runs/roofline.json "$P/results/$arm.json"
  log "done $arm"
done
log "phase 1 complete"
