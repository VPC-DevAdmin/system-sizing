#!/usr/bin/env bash
# retry_dl.sh MODEL... — hf download with up to 6 attempts each (partial files resume)
export HF_HOME=/data/capsim/huggingface
HF=/home/user/.local/share/uv/tools/capsim/bin/hf
for m in "$@"; do
  for i in 1 2 3 4 5 6; do
    $HF download "$m" --quiet >/dev/null 2>>/data/capsim/logs/retry_err.log && { echo "$(date +%T) ok $m (try $i)"; break; }
    echo "$(date +%T) try $i failed $m"; sleep 15
  done
done
