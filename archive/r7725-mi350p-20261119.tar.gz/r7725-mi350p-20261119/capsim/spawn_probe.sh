#!/usr/bin/env bash
# Sample the box while loadgen workers spawn during the 2048 rung.
out=/data/capsim/logs/spawn_probe.log; : > $out
start=$(wc -l < ~/system-sizing/serve.log)
until tail -n +$start ~/system-sizing/serve.log | grep -q "loadgen worker 3 ready"; do sleep 5; done
serve=$(pgrep -f "bin/python.*capsim serve" | head -1)
for i in $(seq 1 24); do
  echo "=== $(date +%T)" >> $out
  top -b -n1 -o %CPU | sed -n 7,20p >> $out
  newest=$(pgrep -f simulator.loadgen_worker | tail -1)
  echo "--- serve $serve" >> $out
  sudo ~/.local/bin/py-spy dump --pid $serve 2>&1 | head -60 >> $out
  echo "--- newest worker $newest ($(ps -o etimes= -p $newest)s old)" >> $out
  sudo ~/.local/bin/py-spy dump --pid $newest 2>&1 | head -40 >> $out
  grep "loadgen worker" ~/system-sizing/serve.log | tail -2 >> $out
  sleep 20
done
echo PROBE_DONE >> $out
