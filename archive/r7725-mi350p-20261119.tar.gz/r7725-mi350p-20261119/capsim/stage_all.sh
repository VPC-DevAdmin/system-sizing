#!/usr/bin/env bash
# wait for the first download list, then stage every tp1 model with retries
while pgrep -f download_models.sh >/dev/null; do sleep 30; done
/data/capsim/retry_dl.sh $(cat /data/capsim/models_tp1.txt)
echo "$(date +%T) stage_all done"
