#!/usr/bin/env bash
# Start the MXFP4 roofline once the current roofline has ended and the
# MXFP4 downloads have finished. Archives the FP8/BF16 state first: a
# fresh roofline run overwrites runs/roofline.json.
cd /home/user/system-sizing
log() { echo "$(date '+%F %T') $*"; }
until curl -s -m 5 localhost:8321/api/status | grep -q '"running":false'; do sleep 120; done
log "current roofline ended"
while pgrep -f "retry_dl.sh amd/" >/dev/null; do sleep 120; done
log "downloads finished"; cat /data/capsim/logs/mxfp4_dl.log
cp -n runs/roofline.json runs/roofline-fp8-bf16-2026-11-15.json && log "archived FP8/BF16 state"
cmp -s runs/roofline.json runs/roofline-fp8-bf16-2026-11-15.json || { log "ARCHIVE MISMATCH, not starting"; exit 1; }
curl -s -m 30 -X POST localhost:8321/api/runs -H 'Content-Type: application/json' -d @/data/capsim/mxfp4_roofline.json
echo; log "MXFP4 roofline posted"
