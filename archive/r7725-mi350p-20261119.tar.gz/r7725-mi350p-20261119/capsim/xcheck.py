"""Post-hoc cross-check of roofline rung rates against client-side bounds.
Every cell uses ignore_eos + fixed output length, so:
  completions bound = (samples + no_content + errors_with_tokens? + in_flight) * out / measure_s
  little bound      = in_flight / tpot_p50
A rung is 'suspect' when the counter exceeds BOTH by > 25%."""
import json, glob, sys, collections
rows = []
for f in glob.glob("runs/run_*/headline_sweep.json"):
    d = json.load(open(f)); out = d["shape"]["output_tokens"]
    for g in d["rungs"]:
        r = g.get("out_tok_s")
        if not r or not g.get("measure_s"):
            continue
        comp = (g["samples"] + g.get("no_content", 0) + (g["in_flight"] or 0)) * out / g["measure_s"]
        lit = (g["in_flight"] or 0) / (g["tpot_p50_ms"] / 1000) if g.get("tpot_p50_ms") else None
        best_bound = max(comp, lit or 0)
        rows.append(dict(run=f.split("/")[1], model=d["model"].split("/")[-1], engine=d["engine"],
                         out=out, conc=g["concurrency"], rate=r, comp=round(comp), little=round(lit) if lit else None,
                         ratio=round(r / best_bound, 2), suspect=r > 1.25 * best_bound,
                         src=g["rate_source"], steady=g["steady_state"], held=g["held"],
                         power=g.get("gpu_power_w")))
sus = [x for x in rows if x["suspect"]]
print(f"rungs {len(rows)}  suspect {len(sus)}")
for e in ("sglang_cuda", "vllm_cuda"):
    print(e, "suspect", sum(1 for x in sus if x["engine"] == e), "of", sum(1 for x in rows if x["engine"] == e))
for x in sorted(sus, key=lambda x: -x["ratio"]):
    print(" ", x["run"], x["model"][:28], x["engine"], x["conc"], x["rate"], "comp", x["comp"], "little", x["little"], x["src"], "steady" if x["steady"] else "UNSTEADY", "held" if x["held"] else "")
# best per model/engine: raw vs clean
best = collections.defaultdict(lambda: [None, None])
for x in rows:
    k = (x["model"], x["engine"])
    if best[k][0] is None or x["rate"] > best[k][0]["rate"]:
        best[k][0] = x
    if not x["suspect"] and (best[k][1] is None or x["rate"] > best[k][1]["rate"]):
        best[k][1] = x
print("\nmodel / engine: raw best -> clean best")
for k in sorted(best):
    a, b = best[k]
    flag = "" if a is b else "  CHANGED"
    print(f"  {k[0][:34]:34} {k[1]:12} {a['rate']:>9} -> {b['rate'] if b else '-':>9}{flag}")
